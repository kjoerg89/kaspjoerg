
clear; close all; addpath(genpath(pwd)); clc;

%% Settings
setup.nuc       = 0.016;
setup.nui       = 0.016;
setup.K         = 120;
setup.startdate = datenum(1990,1,1);
setup.startdate2= datenum(1980,1,1);
setup.enddate   = datenum(2018,8,1); % last consumption data is August 1, 2018
setup.mats      = [1 2 3 5 7 10 15 20];
setup.h         = 12;
setup.B         = 10000;

%% Prepare data set
data  = xlsread('macroyield.xlsx');
yc    = data(2:end,8:end)/100;
tauc  = GetTau(data(2:end,5),setup.nuc,setup.K);
taui  = GetTau(data(2:end,4),setup.nui,setup.K);
dates = datenum(data(2:end,1:3));

idx  = real((setup.startdate2<dates))+real((dates<=setup.enddate)) == 2;
yLS  = yc(idx,setup.mats*12);
V    = cov(yLS); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = yLS*Wy';
tauL = GetTau(PC(:,1),0.016,120); tauL = tauL(121:end);
tauS = GetTau(PC(:,2),0.016,120); tauS = tauS(121:end);

idx  = real((setup.startdate<dates))+real((dates<=setup.enddate)) == 2;
yc   = yc(idx,:);
tauc = tauc(idx,1);
taui = taui(idx,1);

rx   = -(setup.mats(2:end)*12-setup.h).*yc(1+setup.h:end,12*setup.mats(2:end)-setup.h)/12 + 12*setup.mats(2:end).*yc(1:end-setup.h,12*setup.mats(2:end))/12 - setup.h*yc(1:end-setup.h,setup.h)/12; 
ycBoot = yc;
yc   = yc(:,setup.mats*12);
V    = cov(yc); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = yc*Wy';

regshort = nwest(yc(:,1),[ones(size(yc,1),1) taui tauc],0);

if any(any(isnan([yc tauc taui]))); disp('NaN in dataset'); return; end;

%% Cointegrating relations
beta = [ones(size(yc,1),1) taui tauc]\yc; e = yc- [ones(size(yc,1),1) taui tauc]*beta; Ve = cov(e); SDe = sqrt(diag(Ve)); Re = Ve./(SDe*SDe'); [We,Pe,Ee] = pcacov(Re); We = We'; PCe = e*We';

%% Identify predictive factor
regIDF.y3 = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3)],setup.h); % 3 factor spanned model
regIDF.y5 = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:5)],setup.h); % 5 factor spanned model
regIDF.pi = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) taui(1:end-setup.h,1)],setup.h); % inflation trend
regIDF.ii = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) regshort.yhat(1:end-setup.h,1)],setup.h); % nominal short rate trend
regIDF.ls = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) taui(1:end-setup.h,1) tauc(1:end-setup.h,1)],setup.h); % infl and cons trend
regIDF.ic = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) regshort.yhat(1:end-setup.h,1) tauc(1:end-setup.h,1)],setup.h); % value added from cons trend

regIDF.L  = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) tauL(1:end-setup.h,1) ],setup.h); % level trend
regIDF.S  = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) tauS(1:end-setup.h,1) ],setup.h); % slope trend
regIDF.LS = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) tauL(1:end-setup.h,1) tauS(1:end-setup.h,1)],setup.h); % level, slope trends
regIDF.LS2= hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) tauL(1:end-setup.h,1) tauS(1:end-setup.h,1) taui(1:end-setup.h,1)],setup.h); % level, slope, and inf trends 
regIDF.LS3= hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) tauL(1:end-setup.h,1) tauS(1:end-setup.h,1) tauc(1:end-setup.h,1)],setup.h); % level, slope, and cons trends 
regIDF.LS4= hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) tauL(1:end-setup.h,1) tauS(1:end-setup.h,1) taui(1:end-setup.h,1) tauc(1:end-setup.h,1)],setup.h); % level, slope, and macro trends 

regIDF.cyc= hhreg(mean(rx,2),[ones(size(rx,1),1) PCe(1:end-setup.h,1:3)],setup.h); % cyclical

%% Maturity-specific regressions
for i = 1:size(setup.mats,2)-1
    eval(['regRFy3.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) regIDF.y3.yhat],setup.h);']);
    eval(['regRFy5.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) regIDF.y5.yhat],setup.h);']);
    eval(['regRFpi.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) regIDF.pi.yhat],setup.h);']);
    eval(['regRFii.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) regIDF.ii.yhat],setup.h);']);
    eval(['regRFls.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) regIDF.ls.yhat],setup.h);']);
    eval(['regy3.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) PC(1:end-setup.h,1:3)],setup.h);']);
    eval(['regy5.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) PC(1:end-setup.h,1:5)],setup.h);']);
    eval(['regpi.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) taui(1:end-setup.h,1)],setup.h);']);
    eval(['regii.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) regshort.yhat(1:end-setup.h,1)],setup.h);']);
    eval(['regls.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) taui(1:end-setup.h,1) tauc(1:end-setup.h,1)],setup.h);']);
    eval(['regic.reg' num2str(setup.mats(1+i)) ' = hhreg(rx(:,i),[ones(size(rx,1),1) PC(1:end-setup.h,1:3) regshort.yhat(1:end-setup.h,1) tauc(1:end-setup.h,1)],setup.h);']);
end

%% Construct Wald stats
Wy5   = NaN(size(setup.mats,2),1);
Wpi   = NaN(size(setup.mats,2),1);
Wii   = NaN(size(setup.mats,2),1);
Wls   = NaN(size(setup.mats,2),1);
Wic   = NaN(size(setup.mats,2),1);
Wls2  = NaN(size(setup.mats,2),1);
Wic2  = NaN(size(setup.mats,2),1);
dR2y5 = NaN(size(setup.mats,2),1);
dR2pi = NaN(size(setup.mats,2),1);
dR2ii = NaN(size(setup.mats,2),1);
dR2ls = NaN(size(setup.mats,2),1);
dR2ic = NaN(size(setup.mats,2),1);
dR2ls2= NaN(size(setup.mats,2),1);
dR2ic2= NaN(size(setup.mats,2),1);
for i = 1:size(setup.mats,2)-1
    eval(['V = tril(regy5.reg' num2str(setup.mats(1+i)) '.V) + tril(regy5.reg' num2str(setup.mats(1+i)) '.V)'' - diag(diag(regy5.reg' num2str(setup.mats(1+i)) '.V)); V = nearestSPD(V);']);
    eval(['[~,~,Wy5(i,1)] = waldtest(regy5.reg' num2str(setup.mats(1+i)) '.beta(5:end)'',[zeros(2,4) eye(2)],V);']);
    eval(['dR2y5(i,1) = regy5.reg' num2str(setup.mats(1+i)) '.rsqr-regy3.reg' num2str(setup.mats(1+i)) '.rsqr;']);
    
    eval(['V = tril(regpi.reg' num2str(setup.mats(1+i)) '.V) + tril(regpi.reg' num2str(setup.mats(1+i)) '.V)'' - diag(diag(regpi.reg' num2str(setup.mats(1+i)) '.V)); V = nearestSPD(V);']);
    eval(['[~,~,Wpi(i,1)] = waldtest(regpi.reg' num2str(setup.mats(1+i)) '.beta(5:end)'',[zeros(1,4) eye(1)],V);']);
    eval(['dR2pi(i,1) = regpi.reg' num2str(setup.mats(1+i)) '.rsqr-regy3.reg' num2str(setup.mats(1+i)) '.rsqr;']);
    
    eval(['V = tril(regii.reg' num2str(setup.mats(1+i)) '.V) + tril(regii.reg' num2str(setup.mats(1+i)) '.V)'' - diag(diag(regii.reg' num2str(setup.mats(1+i)) '.V)); V = nearestSPD(V);']);
    eval(['[~,~,Wii(i,1)] = waldtest(regii.reg' num2str(setup.mats(1+i)) '.beta(5:end)'',[zeros(1,4) eye(1)],V);']);
    eval(['dR2ii(i,1) = regii.reg' num2str(setup.mats(1+i)) '.rsqr-regy3.reg' num2str(setup.mats(1+i)) '.rsqr;']);
    
    eval(['V = tril(regls.reg' num2str(setup.mats(1+i)) '.V) + tril(regls.reg' num2str(setup.mats(1+i)) '.V)'' - diag(diag(regls.reg' num2str(setup.mats(1+i)) '.V)); V = nearestSPD(V);']);
    eval(['[~,~,Wls(i,1)] = waldtest(regls.reg' num2str(setup.mats(1+i)) '.beta(5:end)'',[zeros(2,4) eye(2)],V);']);
    eval(['dR2ls(i,1) = regls.reg' num2str(setup.mats(1+i)) '.rsqr-regy3.reg' num2str(setup.mats(1+i)) '.rsqr;']);
    
    eval(['V = tril(regic.reg' num2str(setup.mats(1+i)) '.V) + tril(regic.reg' num2str(setup.mats(1+i)) '.V)'' - diag(diag(regic.reg' num2str(setup.mats(1+i)) '.V)); V = nearestSPD(V);']);
    eval(['[~,~,Wic(i,1)] = waldtest(regic.reg' num2str(setup.mats(1+i)) '.beta(5:end)'',[zeros(2,4) eye(2)],V);']);
    eval(['dR2ic(i,1) = regic.reg' num2str(setup.mats(1+i)) '.rsqr-regy3.reg' num2str(setup.mats(1+i)) '.rsqr;']);
    
    eval(['V = tril(regls.reg' num2str(setup.mats(1+i)) '.V) + tril(regls.reg' num2str(setup.mats(1+i)) '.V)'' - diag(diag(regls.reg' num2str(setup.mats(1+i)) '.V)); V = nearestSPD(V);']);
    eval(['[~,~,Wls2(i,1)] = waldtest(regls.reg' num2str(setup.mats(1+i)) '.beta(6:end)'',[zeros(1,5) eye(1)],V);']);
    eval(['dR2ls2(i,1) = regls.reg' num2str(setup.mats(1+i)) '.rsqr-regpi.reg' num2str(setup.mats(1+i)) '.rsqr;']);
    
    eval(['V = tril(regic.reg' num2str(setup.mats(1+i)) '.V) + tril(regic.reg' num2str(setup.mats(1+i)) '.V)'' - diag(diag(regic.reg' num2str(setup.mats(1+i)) '.V)); V = nearestSPD(V);']);
    eval(['[~,~,Wic2(i,1)] = waldtest(regic.reg' num2str(setup.mats(1+i)) '.beta(6:end)'',[zeros(1,5) eye(1)],V);']);
    eval(['dR2ic2(i,1) = regic.reg' num2str(setup.mats(1+i)) '.rsqr-regii.reg' num2str(setup.mats(1+i)) '.rsqr;']);
end

V         = tril(regIDF.y5.V) + tril(regIDF.y5.V)' - diag(diag(regIDF.y5.V)); V = nearestSPD(V);
[~,~,Wy5(end,1)] = waldtest(regIDF.y5.beta(5:end)',[zeros(2,4) eye(2)],V);
dR2y5(end,1)     = regIDF.y5.rsqr-regIDF.y3.rsqr;

V         = tril(regIDF.pi.V) + tril(regIDF.pi.V)' - diag(diag(regIDF.pi.V)); V = nearestSPD(V);
[~,~,Wpi(end,1)] = waldtest(regIDF.pi.beta(5:end)',[zeros(1,4) eye(1)],V);
dR2pi(end,1)     = regIDF.pi.rsqr-regIDF.y3.rsqr;

V         = tril(regIDF.ii.V) + tril(regIDF.ii.V)' - diag(diag(regIDF.ii.V)); V = nearestSPD(V);
[~,~,Wii(end,1)] = waldtest(regIDF.ii.beta(5:end)',[zeros(1,4) eye(1)],V);
dR2ii(end,1)     = regIDF.ii.rsqr-regIDF.y3.rsqr;

V         = tril(regIDF.ls.V) + tril(regIDF.ls.V)' - diag(diag(regIDF.ls.V)); V = nearestSPD(V);
[~,~,Wls(end,1)] = waldtest(regIDF.ls.beta(5:end)',[zeros(2,4) eye(2)],V);
dR2ls(end,1)     = regIDF.ls.rsqr-regIDF.y3.rsqr;

V         = tril(regIDF.ic.V) + tril(regIDF.ic.V)' - diag(diag(regIDF.ic.V)); V = nearestSPD(V);
[~,~,Wic(end,1)] = waldtest(regIDF.ic.beta(5:end)',[zeros(2,4) eye(2)],V);
dR2ic(end,1)     = regIDF.ic.rsqr-regIDF.y3.rsqr;

V         = tril(regIDF.ls.V) + tril(regIDF.ls.V)' - diag(diag(regIDF.ls.V)); V = nearestSPD(V);
[~,~,Wls2(end,1)] = waldtest(regIDF.ls.beta(6:end)',[zeros(1,5) eye(1)],V);
dR2ls2(end,1)     = regIDF.ls.rsqr-regIDF.pi.rsqr;

V         = tril(regIDF.ic.V) + tril(regIDF.ic.V)' - diag(diag(regIDF.ic.V)); V = nearestSPD(V);
[~,~,Wic2(end,1)] = waldtest(regIDF.ic.beta(6:end)',[zeros(1,5) eye(1)],V);
dR2ic2(end,1)     = regIDF.ic.rsqr-regIDF.ii.rsqr;

%% Bauer & Hamilton bootstrap
critvalBHy5 = BauerHamiltonBoot(ycBoot,PC(:,1:3),PC(:,4:5),setup.B,setup); 
critvalBHpi = BauerHamiltonBoot(ycBoot,PC(:,1:3),taui,setup.B,setup);
critvalBHii = BauerHamiltonBoot(ycBoot,PC(:,1:3),regshort.yhat,setup.B,setup);
critvalBHls = BauerHamiltonBoot(ycBoot,PC(:,1:3),[taui tauc],setup.B,setup);
critvalBHic = BauerHamiltonBoot(ycBoot,PC(:,1:3),[regshort.yhat tauc],setup.B,setup);

critvalBHls2 = BauerHamiltonBoot2(ycBoot,PC(:,1:3),tauc,setup.B,setup,taui);
critvalBHic2 = BauerHamiltonBoot2(ycBoot,PC(:,1:3),tauc,setup.B,setup,regshort.yhat);

[100-invprctile(critvalBHpi.dR2all(:,3),dR2pi(3,1)) 100-invprctile(critvalBHpi.Wall(:,3),Wpi(3,1)); ...
 100-invprctile(critvalBHpi.dR2all(:,5),dR2pi(5,1)) 100-invprctile(critvalBHpi.Wall(:,5),Wpi(5,1));...
 100-invprctile(critvalBHpi.dR2all(:,6),dR2pi(6,1)) 100-invprctile(critvalBHpi.Wall(:,6),Wpi(6,1));...
 100-invprctile(critvalBHpi.dR2all(:,7),dR2pi(7,1)) 100-invprctile(critvalBHpi.Wall(:,7),Wpi(7,1));...
 100-invprctile(critvalBHpi.dR2all(:,end),dR2pi(end,1)) 100-invprctile(critvalBHpi.Wall(:,end),Wpi(end,1))]

[100-invprctile(critvalBHii.dR2all(:,3),dR2ii(3,1)) 100-invprctile(critvalBHii.Wall(:,3),Wii(3,1)); ...
 100-invprctile(critvalBHii.dR2all(:,5),dR2ii(5,1)) 100-invprctile(critvalBHii.Wall(:,5),Wii(5,1));...
 100-invprctile(critvalBHii.dR2all(:,6),dR2ii(6,1)) 100-invprctile(critvalBHii.Wall(:,6),Wii(6,1));...
 100-invprctile(critvalBHii.dR2all(:,7),dR2ii(7,1)) 100-invprctile(critvalBHii.Wall(:,7),Wii(7,1));...
 100-invprctile(critvalBHii.dR2all(:,end),dR2ii(end,1)) 100-invprctile(critvalBHii.Wall(:,end),Wii(end,1))]

[100-invprctile(critvalBHls.dR2all(:,3),dR2ls(3,1)) 100-invprctile(critvalBHls.Wall(:,3),Wls(3,1)); ...
 100-invprctile(critvalBHls.dR2all(:,5),dR2ls(5,1)) 100-invprctile(critvalBHls.Wall(:,5),Wls(5,1));...
 100-invprctile(critvalBHls.dR2all(:,6),dR2ls(6,1)) 100-invprctile(critvalBHls.Wall(:,6),Wls(6,1));...
 100-invprctile(critvalBHls.dR2all(:,7),dR2ls(7,1)) 100-invprctile(critvalBHls.Wall(:,7),Wls(7,1));...
 100-invprctile(critvalBHls.dR2all(:,end),dR2ls(end,1)) 100-invprctile(critvalBHls.Wall(:,end),Wls(end,1))]

[100-invprctile(critvalBHic.dR2all(:,3),dR2ic(3,1)) 100-invprctile(critvalBHic.Wall(:,3),Wic(3,1)); ...
 100-invprctile(critvalBHic.dR2all(:,5),dR2ic(5,1)) 100-invprctile(critvalBHic.Wall(:,5),Wic(5,1));...
 100-invprctile(critvalBHic.dR2all(:,6),dR2ic(6,1)) 100-invprctile(critvalBHic.Wall(:,6),Wic(6,1));...
 100-invprctile(critvalBHic.dR2all(:,7),dR2ic(7,1)) 100-invprctile(critvalBHic.Wall(:,7),Wic(7,1));...
 100-invprctile(critvalBHic.dR2all(:,end),dR2ic(end,1)) 100-invprctile(critvalBHic.Wall(:,end),Wic(end,1))]

[100-invprctile(critvalBHls2.dR2all(:,3),dR2ls2(3,1)) 100-invprctile(critvalBHls2.Wall(:,3),Wls2(3,1)); ...
 100-invprctile(critvalBHls2.dR2all(:,5),dR2ls2(5,1)) 100-invprctile(critvalBHls2.Wall(:,5),Wls2(5,1));...
 100-invprctile(critvalBHls2.dR2all(:,6),dR2ls2(6,1)) 100-invprctile(critvalBHls2.Wall(:,6),Wls2(6,1));...
 100-invprctile(critvalBHls2.dR2all(:,7),dR2ls2(7,1)) 100-invprctile(critvalBHls2.Wall(:,7),Wls2(7,1));...
 100-invprctile(critvalBHls2.dR2all(:,end),dR2ls2(end,1)) 100-invprctile(critvalBHls2.Wall(:,end),Wls2(end,1))]

[100-invprctile(critvalBHic2.dR2all(:,3),dR2ic2(3,1)) 100-invprctile(critvalBHic2.Wall(:,3),Wic2(3,1)); ...
 100-invprctile(critvalBHic2.dR2all(:,5),dR2ic2(5,1)) 100-invprctile(critvalBHic2.Wall(:,5),Wic2(5,1));...
 100-invprctile(critvalBHic2.dR2all(:,6),dR2ic2(6,1)) 100-invprctile(critvalBHic2.Wall(:,6),Wic2(6,1));...
 100-invprctile(critvalBHic2.dR2all(:,7),dR2ic2(7,1)) 100-invprctile(critvalBHic2.Wall(:,7),Wic2(7,1));...
 100-invprctile(critvalBHic2.dR2all(:,end),dR2ic2(end,1)) 100-invprctile(critvalBHic2.Wall(:,end),Wic2(end,1))]