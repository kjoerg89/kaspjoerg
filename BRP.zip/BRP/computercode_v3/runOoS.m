
clear; close all; addpath(genpath(pwd)); clc;

%% Settings
setup.nuc       = 0.016;
setup.nui       = 0.016;
setup.K         = 120;
setup.startdate = datenum(1990,1,1);
setup.enddate   = datenum(2018,8,1); % last consumption data is August 1, 2018
setup.mats      = [1 2 3 5 7 10 15 20];
setup.h         = 12;
setup.train     = 10*12;

%% Prepare data set
data  = xlsread('macroyield.xlsx');
yc    = data(2:end,8:end)/100;
tauc  = GetTau(data(2:end,5),setup.nuc,setup.K);
taui  = GetTau(data(2:end,4),setup.nui,setup.K);
dates = datenum(data(2:end,1:3));

idx  = real((setup.startdate<dates))+real((dates<=setup.enddate)) == 2;
yc   = yc(idx,:);
tauc = tauc(idx,1);
taui = taui(idx,1);

rx   = -(setup.mats(2:end)*12-setup.h).*yc(1+setup.h:end,12*setup.mats(2:end)-setup.h)/12 + 12*setup.mats(2:end).*yc(1:end-setup.h,12*setup.mats(2:end))/12 - setup.h*yc(1:end-setup.h,setup.h)/12; 
yc   = yc(:,setup.mats*12);

regshort = hhreg(yc(:,1),[ones(size(yc,1),1) taui tauc],0);

if any(any(isnan([yc tauc taui]))); disp('NaN in dataset'); return; end;

%% Run out-of-sample exercise
f_HAvg  = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
f_rw    = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
f_y     = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
f_pi    = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);  
f_ii    = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
f_ii2   = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
f_ls    = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
fe_HAvg = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
fe_rw   = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
fe_y    = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
fe_pi   = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);  
fe_ii   = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
fe_ii2  = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);
fe_ls   = NaN(size(rx,1)-setup.train-setup.h+1,size(rx,2)+1);

count = 0;
for t = setup.train:size(rx,1)-setup.h
    count = count + 1;
    
    % get historical average forecast
    f_HAvg(count,1:end-1)  = mean(rx(1:t,:),1);
    fe_HAvg(count,1:end-1) = rx(t+setup.h,:) - f_HAvg(count,1:end-1);
    f_HAvg(count,end)      = mean(mean(rx(1:t,:),2),1);
    fe_HAvg(count,end)     = mean(rx(t+setup.h,:),2) - f_HAvg(count,end);
    
    % get random walk forecast
    f_rw(count,1:end-1)  = rx(t,:);
    fe_rw(count,1:end-1) = rx(t+setup.h,:) - f_rw(count,1:end-1);
    f_rw(count,end)      = mean(rx(t,:),2);
    fe_rw(count,end)     = mean(rx(t+setup.h,:),2) - f_rw(count,end);
    
    V = cov(yc(1:t+setup.h,:)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = yc(1:t+setup.h,:)*Wy'; PC = PC(:,1:3);
   
    % get yields only forecast
    for i = 1:size(rx,2)
        reg           = hhreg(rx(1:t,i),[ones(t,1) PC(1:t,:)],0);
        f_y(count,i)  = [1 PC(t+setup.h,:)]*reg.beta;
        fe_y(count,i) = rx(t+setup.h,i) - f_y(count,i);
    end
    reg             = hhreg(mean(rx(1:t,:),2),[ones(t,1) PC(1:t,:)],0);
    f_y(count,end)  = [1 PC(t+setup.h,:)]*reg.beta;
    fe_y(count,end) = mean(rx(t+setup.h,:),2) - f_y(count,end);
    
    % get yields + pi forecast
    for i = 1:size(rx,2)
        reg            = hhreg(rx(1:t,i),[ones(t,1) PC(1:t,:) taui(1:t,1)],0);
        f_pi(count,i)  = [1 PC(t+setup.h,:) taui(t+setup.h,1)]*reg.beta;
        fe_pi(count,i) = rx(t+setup.h,i) - f_pi(count,i);
    end
    reg              = hhreg(mean(rx(1:t,:),2),[ones(t,1) PC(1:t,:) taui(1:t,1)],0);
    f_pi(count,end)  = [1 PC(t+setup.h,:) taui(t+setup.h,1)]*reg.beta;
    fe_pi(count,end) = mean(rx(t+setup.h,:),2) - f_pi(count,end);
    
    % get yields + i* forecast
    regi = hhreg(yc(1:t+setup.h,1),[ones(t+setup.h,1) taui(1:t+setup.h,1) tauc(1:t+setup.h,1)],0);
    for i = 1:size(rx,2)
        reg            = hhreg(rx(1:t,i),[ones(t,1) PC(1:t,:) regi.yhat(1:t,1)],0);
        f_ii(count,i)  = [1 PC(t+setup.h,:) regi.yhat(t+setup.h,1)]*reg.beta;
        fe_ii(count,i) = rx(t+setup.h,i) - f_ii(count,i);
    end
    reg              = hhreg(mean(rx(1:t,:),2),[ones(t,1) PC(1:t,:) regi.yhat(1:t,1)],0);
    f_ii(count,end)  = [1 PC(t+setup.h,:) regi.yhat(t+setup.h,1)]*reg.beta;
    fe_ii(count,end) = mean(rx(t+setup.h,:),2) - f_ii(count,end);
    
    % get yields + i* forecast (fixed cointegration relation for i*)
    for i = 1:size(rx,2)
        reg            = hhreg(rx(1:t,i),[ones(t,1) PC(1:t,:) regshort.yhat(1:t,1)],0);
        f_ii2(count,i)  = [1 PC(t+setup.h,:) regshort.yhat(t+setup.h,1)]*reg.beta;
        fe_ii2(count,i) = rx(t+setup.h,i) - f_ii2(count,i);
    end
    reg              = hhreg(mean(rx(1:t,:),2),[ones(t,1) PC(1:t,:) regi.yhat(1:t,1)],0);
    f_ii2(count,end)  = [1 PC(t+setup.h,:) regshort.yhat(t+setup.h,1)]*reg.beta;
    fe_ii2(count,end) = mean(rx(t+setup.h,:),2) - f_ii2(count,end);
    
    % get yields + pi and c forecast
    for i = 1:size(rx,2)
        reg            = hhreg(rx(1:t,i),[ones(t,1) PC(1:t,:) taui(1:t,1) tauc(1:t,1)],0);
        f_ls(count,i)  = [1 PC(t+setup.h,:) taui(t+setup.h,1) tauc(t+setup.h,1)]*reg.beta;
        fe_ls(count,i) = rx(t+setup.h,i) - f_ls(count,i);
    end
    reg              = hhreg(mean(rx(1:t,:),2),[ones(t,1) PC(1:t,:) taui(1:t,1) tauc(1:t,1)],0);
    f_ls(count,end)  = [1 PC(t+setup.h,:) taui(t+setup.h,1) tauc(t+setup.h,1)]*reg.beta;
    fe_ls(count,end) = mean(rx(t+setup.h,:),2) - f_ls(count,end);
end

% RMSE = [sqrt(mean(fe_HAvg.^2,1));sqrt(mean(fe_rw.^2,1));sqrt(mean(fe_y.^2,1));sqrt(mean(fe_pi.^2,1));sqrt(mean(fe_ii.^2,1));sqrt(mean(fe_ii2.^2,1));sqrt(mean(fe_ls.^2,1))]'

MSEy   = mean(fe_y.^2,1);
MSEpi  = mean(fe_pi.^2,1);
MSEii  = mean(fe_ii.^2,1);
MSEii2 = mean(fe_ii2.^2,1);
MSEls  = mean(fe_ls.^2,1);

Roos = [1-MSEpi([3 5 6 7 8])./MSEy([3 5 6 7 8]); 1-MSEii([3 5 6 7 8])./MSEy([3 5 6 7 8]); 1-MSEii2([3 5 6 7 8])./MSEy([3 5 6 7 8]); 1-MSEls([3 5 6 7 8])./MSEy([3 5 6 7 8])]'

regCW_y5  = hhreg(fe_y(:,3).^2-fe_ls(:,3).^2+(f_y(:,3)-f_ls(:,3)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_y10 = hhreg(fe_y(:,5).^2-fe_ls(:,5).^2+(f_y(:,5)-f_ls(:,5)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_y15 = hhreg(fe_y(:,6).^2-fe_ls(:,6).^2+(f_y(:,6)-f_ls(:,6)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_y20 = hhreg(fe_y(:,7).^2-fe_ls(:,7).^2+(f_y(:,7)-f_ls(:,7)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_ybar= hhreg(fe_y(:,end).^2-fe_ls(:,end).^2+(f_y(:,end)-f_ls(:,end)).^2,ones(size(fe_ls,1),1),18*2/3);

regCW_pi5  = hhreg(fe_pi(:,3).^2-fe_ls(:,3).^2+(f_pi(:,3)-f_ls(:,3)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_pi10 = hhreg(fe_pi(:,5).^2-fe_ls(:,5).^2+(f_pi(:,5)-f_ls(:,5)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_pi15 = hhreg(fe_pi(:,6).^2-fe_ls(:,6).^2+(f_pi(:,6)-f_ls(:,6)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_pi20 = hhreg(fe_pi(:,7).^2-fe_ls(:,7).^2+(f_pi(:,7)-f_ls(:,7)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_pibar= hhreg(fe_pi(:,end).^2-fe_ls(:,end).^2+(f_pi(:,end)-f_ls(:,end)).^2,ones(size(fe_ls,1),1),18*2/3);

regCW_ii5  = hhreg(fe_ii(:,3).^2-fe_ls(:,3).^2+(f_ii(:,3)-f_ls(:,3)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_ii10 = hhreg(fe_ii(:,5).^2-fe_ls(:,5).^2+(f_ii(:,5)-f_ls(:,5)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_ii15 = hhreg(fe_ii(:,6).^2-fe_ls(:,6).^2+(f_ii(:,6)-f_ls(:,6)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_ii20 = hhreg(fe_ii(:,7).^2-fe_ls(:,7).^2+(f_ii(:,7)-f_ls(:,7)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_iibar= hhreg(fe_ii(:,end).^2-fe_ls(:,end).^2+(f_ii(:,end)-f_ls(:,end)).^2,ones(size(fe_ls,1),1),18*2/3);

regCW_ii25  = hhreg(fe_ii2(:,3).^2-fe_ls(:,3).^2+(f_ii2(:,3)-f_ls(:,3)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_ii210 = hhreg(fe_ii2(:,5).^2-fe_ls(:,5).^2+(f_ii2(:,5)-f_ls(:,5)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_ii215 = hhreg(fe_ii2(:,6).^2-fe_ls(:,6).^2+(f_ii2(:,6)-f_ls(:,6)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_ii220 = hhreg(fe_ii2(:,7).^2-fe_ls(:,7).^2+(f_ii2(:,7)-f_ls(:,7)).^2,ones(size(fe_ls,1),1),18*2/3);
regCW_ii2bar= hhreg(fe_ii2(:,end).^2-fe_ls(:,end).^2+(f_ii2(:,end)-f_ls(:,end)).^2,ones(size(fe_ls,1),1),18*2/3);

ENCpval = [1-normcdf(regCW_y5.tstat) 1-normcdf(regCW_pi5.tstat) 1-normcdf(regCW_ii5.tstat) 1-normcdf(regCW_ii25.tstat); ...
           1-normcdf(regCW_y10.tstat) 1-normcdf(regCW_pi10.tstat) 1-normcdf(regCW_ii10.tstat) 1-normcdf(regCW_ii210.tstat); ...
           1-normcdf(regCW_y15.tstat) 1-normcdf(regCW_pi15.tstat) 1-normcdf(regCW_ii15.tstat) 1-normcdf(regCW_ii215.tstat); ...
           1-normcdf(regCW_y20.tstat) 1-normcdf(regCW_pi20.tstat) 1-normcdf(regCW_ii20.tstat) 1-normcdf(regCW_ii220.tstat);
           1-normcdf(regCW_ybar.tstat) 1-normcdf(regCW_pibar.tstat) 1-normcdf(regCW_iibar.tstat) 1-normcdf(regCW_ii2bar.tstat);]
       
% reference: Clark and West (2007), Journal of Econometrics

cum_sfe_y  = cumsum(fe_ls.^2,1)-cumsum(fe_y.^2,1);
cum_sfe_pi = cumsum(fe_pi.^2,1)-cumsum(fe_y.^2,1);
cum_sfe_ii = cumsum(fe_ii.^2,1)-cumsum(fe_y.^2,1);
cum_sfe_ls = cumsum(fe_ls.^2,1)-cumsum(fe_y.^2,1);