
function tau = GetTau(y,nu,K)

T = size(y,1);

tau = NaN(T,1);
for t = 1:T
    if t <= K
        tau(t,1) = nu*(1-nu).^(t-1:-1:0)*y(1:t,1)/(nu*sum((1-nu).^(t-1:-1:0)));
    else
        tau(t,1) = nu*(1-nu).^(K-1:-1:0)*y(t-K+1:t,1)/(nu*sum((1-nu).^(K-1:-1:0)));
    end
end

end