
function [RF,out] = getRF(rx,yc,taui,tauc,y3m,setup,regtype,enforceLVL,np)

if enforceLVL
    reg3m  = nwest(yc(:,1)-taui,[ones(size(yc(:,1),1),1) tauc],0);
%     reg3m  = nwest(y3m-taui,[ones(size(y3m,1),1) tauc],0);
else
    reg3m  = nwest(yc(:,1),[ones(size(yc(:,1),1),1) taui tauc],0);
%     reg3m  = nwest(y3m,[ones(size(y3m,1),1) taui tauc],0);
end

%% Get cycles
e = NaN(size(yc));
for i = 1:size(yc,2)
    if enforceLVL
        if strcmp(regtype,'y')
            e(:,i) = yc(:,i);
        elseif strcmp(regtype,'pi')
            e(:,i) = yc(:,i)-taui;
        elseif strcmp(regtype,'i')
            e(:,i) = yc(:,i)-taui-reg3m.yhat;
        elseif strcmp(regtype,'ls')
            regi   = nwest(yc(:,i)-taui,[ones(size(yc,1),1) tauc],0);
            e(:,i) = regi.resid;
        end
    else
        if strcmp(regtype,'y')
            e(:,i) = yc(:,i);
        elseif strcmp(regtype,'pi')
            regi   = nwest(yc(:,i),[ones(size(yc,1),1) taui],0);
            e(:,i) = regi.resid;
        elseif strcmp(regtype,'i')
            regi   = nwest(yc(:,i),[ones(size(yc,1),1) reg3m.yhat],0);
            e(:,i) = regi.resid;
        elseif strcmp(regtype,'ls')
            regi   = nwest(yc(:,i),[ones(size(yc,1),1) taui tauc],0);
            e(:,i) = regi.resid;
        end
    end  
end

%% Get factors
V = cov(e); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); We = W(:,1:np)'; PC = e*We';

%% Identify return factor
% regRF = hhreg(sum(rx./repmat(setup.mats(2:end),size(rx,1),1),2),[ones(size(rx,1),1) PC(1:end-setup.h,:)],setup.h);
regRF = hhreg(mean(rx,2),[ones(size(rx,1),1) PC(1:end-setup.h,:)],setup.h);

%% Report output
RF = regRF.yhat;

out.e     = e;
out.V     = V;
out.SD    = SD;
out.R     = R;
out.W     = W;
out.P     = P;
out.E     = E;
out.We    = We;
out.PC    = PC;
out.regRF = regRF;
out.reg3m = reg3m;

end