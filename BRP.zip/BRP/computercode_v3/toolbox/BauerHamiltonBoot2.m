
function CritValBH = BauerHamiltonBoot2(y,PC,RF,numBoot,setup,X) 

rng(357);

RFX = [RF X];

%% Estimate empirical distributions

% pc var
phi0  = NaN(size(PC,2),1);
phix  = NaN(size(PC,2),size(PC,2));
phixx = NaN(size(PC,2),size(X,2));
epspc = NaN(size(PC,2),size(PC,1)-1); 
for i = 1:size(PC,2)
    regPCVAR   = hhreg(PC(2:end,i),[ones(size(PC,1)-1,1) PC(1:end-1,:) X(1:end-1,:)],0);
    phi0(i,1)  = regPCVAR.beta(1);
    phix(i,:)  = regPCVAR.beta(2:1+size(PC,2))';
    phixx(i,:) = regPCVAR.beta(2+size(PC,2):end)';
    epspc(i,:) = regPCVAR.resid';
end

% cross-section
A = NaN(size(y,2),1);
B = NaN(size(y,2),size(PC,2));
epsy = NaN(size(y,2),size(y,1));
for j = 1:size(y,2)
    regYPC = hhreg(y(:,j),[ones(size(y,1),1) PC],0);
    A(j,1) = regYPC.beta(1);
    B(j,:) = regYPC.beta(2:end)';
    epsy(j,:) = regYPC.resid';
end
epsy = epsy(setup.mats*12,:); 
sigy = std(epsy(:));

% return factor var
psi0  = NaN(size(RFX,2),1);
psix  = zeros(size(RFX,2),size(RFX,2));
epsrf = NaN(size(RFX,2),size(RFX,1)-1); 
for k = 1:size(RFX,2)
    regRFVAR   = hhreg(RFX(2:end,k),[ones(size(RFX,1)-1,1) RFX(1:end-1,k)],0);
    psi0(k,1)  = regRFVAR.beta(1);
    psix(k,k)  = regRFVAR.beta(2)';
    epsrf(k,:) = regRFVAR.resid';
end

% % return factor var
% chi0  = NaN(size(X,2),1);
% chix  = NaN(size(X,2),size(X,2));
% epsx  = NaN(size(X,2),size(X,1)-1); 
% for k = 1:size(X,2)
%     regXVAR   = hhreg(X(2:end,k),[ones(size(X,1)-1,1) X(1:end-1,:)],0);
%     chi0(k,1) = regXVAR.beta(1);
%     chix(k,:) = regXVAR.beta(2:end)';
%     epsx(k,:) = regXVAR.resid';
% end

%% Bootstrap
W   = NaN(numBoot,size(setup.mats,2));
dR2 = NaN(numBoot,size(setup.mats,2));
BET = NaN(size(RF,2),size(setup.mats,2),numBoot);
for b = 1:numBoot
    % generate bootstrap sample
    PCb = NaN(size(PC,2),size(PC,1));
    RFb = NaN(size(RF,2),size(RF,1));
    Xb  = NaN(size(X,2),size(X,1));
    yb  = NaN(size(y,2),size(y,1));
    for t = 1:size(yb,2)
        if t == 1
            PCb(:,t) = mean(PC(:,:),1)'; %PC(1,:)';
            RFb(:,t) = mean(RF(:,:),1)'; %RF(1,:)';
            Xb(:,t)  = mean(X(:,:),1)'; %X(1,:)';
        else
            l = randi(size(y,1)-1,1,1);
            
            RFX = [RFb(:,t-1);Xb(:,t-1)];
            
            RFX = psi0 + psix*RFX + epsrf(:,l);
            
            PCb(:,t) = phi0 + phix*PCb(:,t-1) + phixx*Xb(:,t-1) + epspc(:,l);
            RFb(:,t) = RFX(size(RF,2),:);
            Xb(:,t)  = RFX(size(RF,2)+1:end);
        end
        yb(:,t)  = A + B*PCb(:,t) + sigy*randn(size(yb,1),1);
    end
    
    yb  = yb';
    PCb = PCb';
    RFb = RFb';
    Xb  = Xb';
    
    rxb  = -(setup.mats(2:end)*12-setup.h).*yb(1+setup.h:end,12*setup.mats(2:end)-setup.h)/12 + 12*setup.mats(2:end).*yb(1:end-setup.h,12*setup.mats(2:end))/12 - setup.h*yb(1:end-setup.h,setup.h)/12;
    
    for n = 1:size(rxb,2)
        reg1 = hhreg(rxb(:,n),[ones(size(rxb,1),1) PCb(1:end-setup.h,:) Xb(1:end-setup.h,:)],setup.h);
        reg2 = hhreg(rxb(:,n),[ones(size(rxb,1),1) PCb(1:end-setup.h,:) Xb(1:end-setup.h,:) RFb(1:end-setup.h,:)],setup.h);
        
        V    = tril(reg2.V) + tril(reg2.V)' - diag(diag(reg2.V)); V = nearestSPD(V);
        [~,~,Wstat] = waldtest(reg2.beta(1+1+size(PCb,2)+size(Xb,2):end)',[zeros(size(RFb,2),size(PCb,2)+size(Xb,2)+1) eye(size(RFb,2))],V);
        
        W(b,n)     = Wstat;
        dR2(b,n)   = reg2.rsqr-reg1.rsqr;
        BET(:,n,b) = reg2.tstat(size(PC,2)+size(X,2)+2:end);
    end
    
    reg1 = hhreg(mean(rxb,2),[ones(size(rxb,1),1) PCb(1:end-setup.h,:) Xb(1:end-setup.h,:)],setup.h);
    reg2 = hhreg(mean(rxb,2),[ones(size(rxb,1),1) PCb(1:end-setup.h,:) Xb(1:end-setup.h,:) RFb(1:end-setup.h,:)],setup.h);
    
    V    = tril(reg2.V) + tril(reg2.V)' - diag(diag(reg2.V)); V = nearestSPD(V);
    [~,~,Wstat] = waldtest(reg2.beta(1+1+size(PCb,2)+size(Xb,2):end)',[zeros(size(RFb,2),size(PCb,2)+size(Xb,2)+1) eye(size(RFb,2))],V);
    
    W(b,end)     = Wstat;
    dR2(b,end)   = reg2.rsqr-reg1.rsqr;  
    BET(:,end,b) = reg2.tstat(size(PC,2)+size(X,2)+2:end);
    b
end

CritValBH.Wall   = W;
CritValBH.W      = prctile(W,[90 95 99],1);
CritValBH.dR2all = dR2;
CritValBH.dR2    = prctile(dR2,[90 95 99],1);
CritValBH.BET005 = prctile(BET,0.5,3);
CritValBH.BET025 = prctile(BET,2.5,3);
CritValBH.BET050 = prctile(BET,5,3);
CritValBH.BET995 = prctile(BET,99.5,3);
CritValBH.BET975 = prctile(BET,97.5,3);
CritValBH.BET950 = prctile(BET,95,3);

end