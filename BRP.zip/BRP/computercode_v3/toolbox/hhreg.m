
function results = hhreg(y,x,nlag)

if (nargin ~= 3); error('Wrong # of arguments to nwest'); end;

% Determining dimensions of y
T   = size(y,1);

%% Setting preliminaries
K       = size(x,2);
Exx     = x'*x/T;
parm    = x\y;
errv    = y - x*parm;
reg_se  = sum(errv.^2)/T;

ww      = 0;
vary    = mean((y - ones(T,1) * mean(y)).^2);
r2      = (1 - reg_se./vary)';
adj_r2  = (1 - (reg_se./vary) * (T-1)/(T-K))';

%% Computing Hansen-Hodrick standard errors

% Compute residuals and covariance matrix
err                 = errv;
inner               = (x.*(err*ones(1,K)))' * (x.*(err*ones(1,K))) / T;

for j=1:nlag
    
    innadd          = (x(1:T-j,:).*(err(1:T-j)*ones(1,K)))'*(x(1+j:T,:).*(err(1+j:T)*ones(1,K)))/T;
    inner           = inner + (1-ww*j/(nlag+1))*(innadd+innadd');
    
end
varb = Exx\inner/Exx/T;

% Making vector of standard errors
seb                 = diag(varb);
seb                 = sign(seb).*(abs(seb).^0.5);
std_err(:,1)        = seb;
t_stat(:,1)         = parm(:,1)./std_err(:,1);

%% Reporting results
results.meth    = 'HH';
results.y       = y;
results.nobs    = T;
results.nvar    = K;
results.beta    = parm;
results.yhat    = x*parm;
results.resid   = errv;
results.sige    = reg_se*T/(T-K);
results.tstat   = t_stat;
results.rsqr    = r2;
results.rbar    = adj_r2;
results.dw      = NaN;
results.stdb    = seb;
results.V       = varb;

end