
clear; close all; addpath(genpath(pwd)); clc;

%% Settings
setup.nuc       = 0.016;
setup.nui       = 0.016;
setup.K         = 120;
setup.startdate = datenum(1990,1,1);
setup.enddate   = datenum(2018,8,1); % last consumption data is August 1, 2018
setup.mats      = [1 2 3 5 7 10 15 20];
setup.h         = 12;

%% Prepare data set
data  = xlsread('macroyield.xlsx');
yc    = data(2:end,8:end)/100;
tauc  = GetTau(data(2:end,5),setup.nuc,setup.K);
taui  = GetTau(data(2:end,4),setup.nui,setup.K);
dates = datenum(data(2:end,1:3));

idx  = real((setup.startdate<dates))+real((dates<=setup.enddate)) == 2;
yc   = yc(idx,:);
tauc = tauc(idx,1);
taui = taui(idx,1);

yc   = yc(:,setup.mats*12);

V = cov(yc); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); W = W'; PC = yc*W'; PC = PC(:,1:3);

regshort = nwest(yc(:,1),[ones(size(yc,1),1) taui tauc],0);

if any(any(isnan([yc tauc taui]))); disp('NaN in dataset'); return; end;

%% Term premia, yields only
reg1 = hhreg(yc(:,1),[ones(size(yc,1),1) PC],0);
a    = reg1.beta(1);
b    = reg1.beta(2:end)';
phi0 = NaN(size(PC,2),1);
phix = NaN(size(PC,2),size(PC,2));
for i = 1:size(PC,2)
    regV      = hhreg(PC(1+setup.h:end,i),[ones(size(PC,1)-setup.h,1) PC(1:end-setup.h,:)],0);
    phi0(i,1) = regV.beta(1);
    phix(i,:) = regV.beta(2:end)';
end

TPy    = NaN(size(yc,1),size(setup.mats,2));
avgeRy = NaN(size(yc,1),size(setup.mats,2));
for t = 1:size(yc,1)
    eR = NaN(max(setup.mats),1);
    for k = 1:size(eR,1)
        if k == 1
            eP = PC(t,:)';
        else
            eP = phi0 + phix*eP;
        end
        eR(k,1) = a + b*eP;
    end
    avgeR = cumsum(eR)./((1:size(eR,1))');   
    TPy(t,:)    = yc(t,:) - avgeR(setup.mats,1)';
    avgeRy(t,:) = avgeR(setup.mats,1)';
end

%% Term premia, yields + pi
reg1 = hhreg(yc(:,1),[ones(size(yc,1),1) PC],0);
a    = reg1.beta(1);
b    = reg1.beta(2:end)';
phi0 = NaN(size(PC,2),1);
phix = NaN(size(PC,2),size(PC,2)+1);
for i = 1:size(PC,2)
    regV      = hhreg(PC(1+setup.h:end,i),[ones(size(PC,1)-setup.h,1) PC(1:end-setup.h,:) taui(1:end-setup.h,1)],0);
    phi0(i,1) = regV.beta(1);
    phix(i,:) = regV.beta(2:end)';
end

TPpi    = NaN(size(yc,1),size(setup.mats,2));
avgeRpi = NaN(size(yc,1),size(setup.mats,2));
for t = 1:size(yc,1)
    eR = NaN(max(setup.mats),1);
    for k = 1:size(eR,1)
        if k == 1
            eP = PC(t,:)';
        else
            eP = phi0 + phix*[eP;taui(t,1)];
        end
        eR(k,1) = a + b*eP;
    end
    avgeR = cumsum(eR)./((1:size(eR,1))');  
    TPpi(t,:)    = yc(t,:) - avgeR(setup.mats,1)';
    avgeRpi(t,:) = avgeR(setup.mats,1)';
end

%% Term premia, yields + i*
reg1 = hhreg(yc(:,1),[ones(size(yc,1),1) PC],0);
a    = reg1.beta(1);
b    = reg1.beta(2:end)';
phi0 = NaN(size(PC,2),1);
phix = NaN(size(PC,2),size(PC,2)+1);
for i = 1:size(PC,2)
    regV      = hhreg(PC(1+setup.h:end,i),[ones(size(PC,1)-setup.h,1) PC(1:end-setup.h,:) regshort.yhat(1:end-setup.h,1)],0);
    phi0(i,1) = regV.beta(1);
    phix(i,:) = regV.beta(2:end)';
end

TPii    = NaN(size(yc,1),size(setup.mats,2));
avgeRii = NaN(size(yc,1),size(setup.mats,2));
for t = 1:size(yc,1)
    eR = NaN(max(setup.mats),1);
    for k = 1:size(eR,1)
        if k == 1
            eP = PC(t,:)';
        else
            eP = phi0 + phix*[eP;regshort.yhat(t,1)];
        end
        eR(k,1) = a + b*eP;
    end
    avgeR = cumsum(eR)./((1:size(eR,1))');  
    TPii(t,:)    = yc(t,:) - avgeR(setup.mats,1)';
    avgeRii(t,:) = avgeR(setup.mats,1)';
end

%% Term premia, yields + pi and c
reg1 = hhreg(yc(:,1),[ones(size(yc,1),1) PC],0);
a    = reg1.beta(1);
b    = reg1.beta(2:end)';
phi0 = NaN(size(PC,2),1);
phix = NaN(size(PC,2),size(PC,2)+2);
for i = 1:size(PC,2)
    regV      = hhreg(PC(1+setup.h:end,i),[ones(size(PC,1)-setup.h,1) PC(1:end-setup.h,:) taui(1:end-setup.h,1) tauc(1:end-setup.h,1)],0);
    phi0(i,1) = regV.beta(1);
    phix(i,:) = regV.beta(2:end)';
end

TPls    = NaN(size(yc,1),size(setup.mats,2));
avgeRls = NaN(size(yc,1),size(setup.mats,2));
for t = 1:size(yc,1)
    eR = NaN(max(setup.mats),1);
    for k = 1:size(eR,1)
        if k == 1
            eP = PC(t,:)';
        else
            eP = phi0 + phix*[eP;taui(t,1);tauc(t,1)];
        end
        eR(k,1) = a + b*eP;
    end
    avgeR = cumsum(eR)./((1:size(eR,1))');  
    TPls(t,:)    = yc(t,:) - avgeR(setup.mats,1)';
    avgeRls(t,:) = avgeR(setup.mats,1)';
end

plot(1:343,TPy(:,6),'-b',1:343,TPpi(:,6),'-r',1:343,TPii(:,6),'-g',1:343,TPls(:,6),'-k',1:343,yc(:,6),'--k')

plot(1:343,avgeRy(:,6),'-b',1:343,avgeRpi(:,6),'-r',1:343,avgeRii(:,6),'-g',1:343,avgeRls(:,6),'-k')

% corr([TPy(:,6) TPpi(:,6) TPii(:,6) TPls(:,6)])
