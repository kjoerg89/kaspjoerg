
clear; close all; addpath(genpath(pwd)); clc;

%% Settings
setup.nuc       = 0.016;
setup.nui       = 0.016;
setup.K         = 120;
setup.startdate = datenum(1990,1,1);
setup.startdate2= datenum(1980,1,1);
setup.enddate   = datenum(2018,8,1); % last consumption data is August 1, 2018
setup.mats      = [1 2 3 5 7 10 15 20];
setup.h         = 12;

setup.adflag    = 2;

%% Prepare data set
data  = xlsread('macroyield.xlsx');
yc    = data(2:end,8:end)/100;
tauc  = GetTau(data(2:end,5),setup.nuc,setup.K);
taui  = GetTau(data(2:end,4),setup.nui,setup.K);
tauii = GetTau(data(2:end,8),setup.nui,setup.K);
dates = datenum(data(2:end,1:3));

idx  = real((setup.startdate2<dates))+real((dates<=setup.enddate)) == 2;
yLS  = yc(idx,setup.mats*12);
V    = cov(yLS); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = yLS*Wy';
tauL = GetTau(PC(:,1),0.016,120); tauL = tauL(121:end);
tauS = GetTau(PC(:,2),0.016,120); tauS = tauS(121:end);

idx  = real((setup.startdate<dates))+real((dates<=setup.enddate)) == 2;
yc   = yc(idx,:);

tauc = tauc(idx,1);
taui = taui(idx,1);
tauii= tauii(idx,1);
yc   = yc(:,setup.mats*12);

regshort = nwest(yc(:,1),[ones(size(yc,1),1) taui tauc],0);

V    = cov(yc); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = yc*Wy';

if any(any(isnan([yc tauc taui]))); disp('NaN in dataset'); return; end;

%% Dickey-Fuller tests, raw data
ADFpval = NaN(size(yc,2)+2,13);
ADFstat = NaN(size(yc,2)+2,13);
ADFbic  = NaN(size(yc,2)+2,13);
for j = 0:12
    for i = 1:size(yc,2)
        [~,ADFpval(i,j+1),ADFstat(i,j+1),~,reg] = adftest(yc(:,i),'model','ARD','lags',j);
        ADFbic(i,j+1) = reg.BIC;
    end
    [~,ADFpval(i+1,j+1),ADFstat(i+1,j+1),~,reg] = adftest(taui,'model','ARD','lags',j);
    ADFbic(i+1,j+1) = reg.BIC;
    [~,ADFpval(i+2,j+1),ADFstat(i+2,j+1),~,reg] = adftest(tauc,'model','ARD','lags',j);
    ADFbic(i+2,j+1) = reg.BIC;
end

Corr_yc = [autocorr(yc(:,1),'NumLags',3) autocorr(yc(:,2),'NumLags',3) autocorr(yc(:,3),'NumLags',3) autocorr(yc(:,4),'NumLags',3) autocorr(yc(:,5),'NumLags',3) ...
           autocorr(yc(:,6),'NumLags',3) autocorr(yc(:,7),'NumLags',3) autocorr(yc(:,8),'NumLags',3)]
       
HL_yc   = (log(0.5)./log(Corr_yc(2,:)))/12      

%% Dickey-Fuller tests, PCA
ADFpvalp = NaN(size(PC,2),13);
ADFstatp = NaN(size(PC,2),13);
ADFbicp  = NaN(size(PC,2),13);
for j = 0:12
    for i = 1:size(PC,2)
        [~,ADFpvalp(i,j+1),ADFstatp(i,j+1),~,reg] = adftest(PC(:,i),'model','ARD','lags',j);
        ADFbicp(i,j+1) = reg.BIC;
    end
end

Corr_p = [autocorr(PC(:,1),'NumLags',3) autocorr(PC(:,2),'NumLags',3) autocorr(PC(:,3),'NumLags',3)]
       
HL_pc  = (log(0.5)./log(Corr_p(2,:)))/12      

%% Cointegration rank test, yields only
[h,pValue,stat,cValue,mles] = jcitest([yc(:,2) yc(:,8)],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest([yc(:,4) yc(:,5)],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest([yc(:,4) yc(:,6)],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest([yc(:,4) yc(:,7)],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest([yc(:,6) yc(:,8)],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest(PC(:,1:2),'model','H1*','lags',setup.adflag);

%% Cointegration rank test, yields and macro trends
[h,pValue,stat,cValue,mles] = jcitest([PC(:,1) taui],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest([PC(:,2) tauc],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest([PC(:,1) taui tauc],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest([PC(:,2) taui tauc],'model','H1*','lags',setup.adflag);
[h,pValue,stat,cValue,mles] = jcitest([PC(:,1:2) taui tauc],'model','H1*','lags',setup.adflag);

%% Cointegration regressions, yields + pi
resyp  = NaN(7,8);
regyp1 = nwest(yc(:,1),[ones(size(yc,1),1) taui],12);
regyp2 = nwest(yc(:,2),[ones(size(yc,1),1) taui],12);
regyp3 = nwest(yc(:,3),[ones(size(yc,1),1) taui],12);
regyp4 = nwest(yc(:,4),[ones(size(yc,1),1) taui],12);
regyp5 = nwest(yc(:,5),[ones(size(yc,1),1) taui],12);
regyp6 = nwest(yc(:,6),[ones(size(yc,1),1) taui],12);
regyp7 = nwest(yc(:,7),[ones(size(yc,1),1) taui],12);
regyp8 = nwest(yc(:,8),[ones(size(yc,1),1) taui],12);

resyp(4,:) = [regyp1.rsqr regyp2.rsqr regyp3.rsqr regyp4.rsqr regyp5.rsqr regyp6.rsqr regyp7.rsqr regyp8.rsqr];

[~,resyp(6,1),resyp(5,1)] = adftest(regyp1.resid,'model','ARD','lags',setup.adflag);
[~,resyp(6,2),resyp(5,2)] = adftest(regyp2.resid,'model','ARD','lags',setup.adflag);
[~,resyp(6,3),resyp(5,3)] = adftest(regyp3.resid,'model','ARD','lags',setup.adflag);
[~,resyp(6,4),resyp(5,4)] = adftest(regyp4.resid,'model','ARD','lags',setup.adflag);
[~,resyp(6,5),resyp(5,5)] = adftest(regyp5.resid,'model','ARD','lags',setup.adflag);
[~,resyp(6,6),resyp(5,6)] = adftest(regyp6.resid,'model','ARD','lags',setup.adflag);
[~,resyp(6,7),resyp(5,7)] = adftest(regyp7.resid,'model','ARD','lags',setup.adflag);
[~,resyp(6,8),resyp(5,8)] = adftest(regyp8.resid,'model','ARD','lags',setup.adflag);

Corr_ep = [autocorr(regyp1.resid,'NumLags',3) autocorr(regyp2.resid,'NumLags',3) autocorr(regyp3.resid,'NumLags',3) autocorr(regyp4.resid,'NumLags',3) autocorr(regyp5.resid,'NumLags',3) ...
           autocorr(regyp6.resid,'NumLags',3) autocorr(regyp7.resid,'NumLags',3) autocorr(regyp8.resid,'NumLags',3)];
resyp(1:3,:) = Corr_ep(2:end,:);
resyp(7,:)  = log(0.5)./log(resyp(1,:));

%% Cointegration regressions, yields + i*
resyi  = NaN(7,8);
regyi1 = nwest(yc(:,1),[ones(size(yc,1),1) regshort.yhat],12);
regyi2 = nwest(yc(:,2),[ones(size(yc,1),1) regshort.yhat],12);
regyi3 = nwest(yc(:,3),[ones(size(yc,1),1) regshort.yhat],12);
regyi4 = nwest(yc(:,4),[ones(size(yc,1),1) regshort.yhat],12);
regyi5 = nwest(yc(:,5),[ones(size(yc,1),1) regshort.yhat],12);
regyi6 = nwest(yc(:,6),[ones(size(yc,1),1) regshort.yhat],12);
regyi7 = nwest(yc(:,7),[ones(size(yc,1),1) regshort.yhat],12);
regyi8 = nwest(yc(:,8),[ones(size(yc,1),1) regshort.yhat],12);

resyi(4,:) = [regyi1.rsqr regyi2.rsqr regyi3.rsqr regyi4.rsqr regyi5.rsqr regyi6.rsqr regyi7.rsqr regyi8.rsqr];

[~,resyi(6,1),resyi(5,1)] = adftest(regyi1.resid,'model','ARD','lags',setup.adflag);
[~,resyi(6,2),resyi(5,2)] = adftest(regyi2.resid,'model','ARD','lags',setup.adflag);
[~,resyi(6,3),resyi(5,3)] = adftest(regyi3.resid,'model','ARD','lags',setup.adflag);
[~,resyi(6,4),resyi(5,4)] = adftest(regyi4.resid,'model','ARD','lags',setup.adflag);
[~,resyi(6,5),resyi(5,5)] = adftest(regyi5.resid,'model','ARD','lags',setup.adflag);
[~,resyi(6,6),resyi(5,6)] = adftest(regyi6.resid,'model','ARD','lags',setup.adflag);
[~,resyi(6,7),resyi(5,7)] = adftest(regyi7.resid,'model','ARD','lags',setup.adflag);
[~,resyi(6,8),resyi(5,8)] = adftest(regyi8.resid,'model','ARD','lags',setup.adflag);

Corr_ei = [autocorr(regyi1.resid,'NumLags',3) autocorr(regyi2.resid,'NumLags',3) autocorr(regyi3.resid,'NumLags',3) autocorr(regyi4.resid,'NumLags',3) autocorr(regyi5.resid,'NumLags',3) ...
           autocorr(regyi6.resid,'NumLags',3) autocorr(regyi7.resid,'NumLags',3) autocorr(regyi8.resid,'NumLags',3)];
resyi(1:3,:) = Corr_ei(2:end,:);
resyi(7,:)  = log(0.5)./log(resyi(1,:));

%% Cointegration regressions, yields + i* (v2)
resyi2  = NaN(7,8);
regyi21 = nwest(yc(:,1)-regshort.yhat,[ones(size(yc,1),1)],12);
regyi22 = nwest(yc(:,2)-regshort.yhat,[ones(size(yc,1),1)],12);
regyi23 = nwest(yc(:,3)-regshort.yhat,[ones(size(yc,1),1)],12);
regyi24 = nwest(yc(:,4)-regshort.yhat,[ones(size(yc,1),1)],12);
regyi25 = nwest(yc(:,5)-regshort.yhat,[ones(size(yc,1),1)],12);
regyi26 = nwest(yc(:,6)-regshort.yhat,[ones(size(yc,1),1)],12);
regyi27 = nwest(yc(:,7)-regshort.yhat,[ones(size(yc,1),1)],12);
regyi28 = nwest(yc(:,8)-regshort.yhat,[ones(size(yc,1),1)],12);

resyi2(4,:) = 1-[var(regyi21.resid)/var(yc(:,1)) var(regyi22.resid)/var(yc(:,2)) var(regyi23.resid)/var(yc(:,3)) var(regyi24.resid)/var(yc(:,4)) var(regyi25.resid)/var(yc(:,5)) var(regyi26.resid)/var(yc(:,6)) var(regyi27.resid)/var(yc(:,7)) var(regyi28.resid)/var(yc(:,8))];

[~,resyi2(6,1),resyi2(5,1)] = adftest(regyi21.resid,'model','ARD','lags',setup.adflag);
[~,resyi2(6,2),resyi2(5,2)] = adftest(regyi22.resid,'model','ARD','lags',setup.adflag);
[~,resyi2(6,3),resyi2(5,3)] = adftest(regyi23.resid,'model','ARD','lags',setup.adflag);
[~,resyi2(6,4),resyi2(5,4)] = adftest(regyi24.resid,'model','ARD','lags',setup.adflag);
[~,resyi2(6,5),resyi2(5,5)] = adftest(regyi25.resid,'model','ARD','lags',setup.adflag);
[~,resyi2(6,6),resyi2(5,6)] = adftest(regyi26.resid,'model','ARD','lags',setup.adflag);
[~,resyi2(6,7),resyi2(5,7)] = adftest(regyi27.resid,'model','ARD','lags',setup.adflag);
[~,resyi2(6,8),resyi2(5,8)] = adftest(regyi28.resid,'model','ARD','lags',setup.adflag);

Corr_ei2 = [autocorr(regyi21.resid,'NumLags',3) autocorr(regyi22.resid,'NumLags',3) autocorr(regyi23.resid,'NumLags',3) autocorr(regyi24.resid,'NumLags',3) autocorr(regyi25.resid,'NumLags',3) ...
           autocorr(regyi26.resid,'NumLags',3) autocorr(regyi27.resid,'NumLags',3) autocorr(regyi28.resid,'NumLags',3)];
resyi2(1:3,:) = Corr_ei2(2:end,:);
resyi2(7,:)  = log(0.5)./log(resyi2(1,:));

%% Cointegration regressions, yields + i* (robust)
regshort2 = nwest(yc(:,1),[ones(size(yc,1),1) tauii],0);

resyii  = NaN(7,8);
regyii1 = nwest(yc(:,1),[ones(size(yc,1),1) regshort2.yhat],12);
regyii2 = nwest(yc(:,2),[ones(size(yc,1),1) regshort2.yhat],12);
regyii3 = nwest(yc(:,3),[ones(size(yc,1),1) regshort2.yhat],12);
regyii4 = nwest(yc(:,4),[ones(size(yc,1),1) regshort2.yhat],12);
regyii5 = nwest(yc(:,5),[ones(size(yc,1),1) regshort2.yhat],12);
regyii6 = nwest(yc(:,6),[ones(size(yc,1),1) regshort2.yhat],12);
regyii7 = nwest(yc(:,7),[ones(size(yc,1),1) regshort2.yhat],12);
regyii8 = nwest(yc(:,8),[ones(size(yc,1),1) regshort2.yhat],12);

resyii(4,:) = [regyii1.rsqr regyii2.rsqr regyii3.rsqr regyii4.rsqr regyii5.rsqr regyii6.rsqr regyii7.rsqr regyii8.rsqr];

[~,resyii(6,1),resyii(5,1)] = adftest(regyii1.resid,'model','ARD','lags',setup.adflag);
[~,resyii(6,2),resyii(5,2)] = adftest(regyii2.resid,'model','ARD','lags',setup.adflag);
[~,resyii(6,3),resyii(5,3)] = adftest(regyii3.resid,'model','ARD','lags',setup.adflag);
[~,resyii(6,4),resyii(5,4)] = adftest(regyii4.resid,'model','ARD','lags',setup.adflag);
[~,resyii(6,5),resyii(5,5)] = adftest(regyii5.resid,'model','ARD','lags',setup.adflag);
[~,resyii(6,6),resyii(5,6)] = adftest(regyii6.resid,'model','ARD','lags',setup.adflag);
[~,resyii(6,7),resyii(5,7)] = adftest(regyii7.resid,'model','ARD','lags',setup.adflag);
[~,resyii(6,8),resyii(5,8)] = adftest(regyii8.resid,'model','ARD','lags',setup.adflag);

Corr_eii = [autocorr(regyii1.resid,'NumLags',3) autocorr(regyii2.resid,'NumLags',3) autocorr(regyii3.resid,'NumLags',3) autocorr(regyii4.resid,'NumLags',3) autocorr(regyii5.resid,'NumLags',3) ...
             autocorr(regyii6.resid,'NumLags',3) autocorr(regyii7.resid,'NumLags',3) autocorr(regyii8.resid,'NumLags',3)];
resyii(1:3,:) = Corr_eii(2:end,:);
resyii(7,:)  = log(0.5)./log(resyii(1,:));

%% Cointegration regressions, yields + i* (robust, v2)
regshort2 = nwest(yc(:,1),[ones(size(yc,1),1) tauii],0);

resyii2  = NaN(7,8);
regyii21 = nwest(yc(:,1)-regshort2.yhat,[ones(size(yc,1),1)],12);
regyii22 = nwest(yc(:,2)-regshort2.yhat,[ones(size(yc,1),1)],12);
regyii23 = nwest(yc(:,3)-regshort2.yhat,[ones(size(yc,1),1)],12);
regyii24 = nwest(yc(:,4)-regshort2.yhat,[ones(size(yc,1),1)],12);
regyii25 = nwest(yc(:,5)-regshort2.yhat,[ones(size(yc,1),1)],12);
regyii26 = nwest(yc(:,6)-regshort2.yhat,[ones(size(yc,1),1)],12);
regyii27 = nwest(yc(:,7)-regshort2.yhat,[ones(size(yc,1),1)],12);
regyii28 = nwest(yc(:,8)-regshort2.yhat,[ones(size(yc,1),1)],12);

resyii2(4,:) = 1-[var(regyii21.resid)/var(yc(:,1)) var(regyii22.resid)/var(yc(:,2)) var(regyii23.resid)/var(yc(:,3)) var(regyii24.resid)/var(yc(:,4)) var(regyii25.resid)/var(yc(:,5)) var(regyii26.resid)/var(yc(:,6)) var(regyii27.resid)/var(yc(:,7)) var(regyii28.resid)/var(yc(:,8))];

[~,resyii2(6,1),resyii2(5,1)] = adftest(regyii21.resid,'model','ARD','lags',setup.adflag);
[~,resyii2(6,2),resyii2(5,2)] = adftest(regyii22.resid,'model','ARD','lags',setup.adflag);
[~,resyii2(6,3),resyii2(5,3)] = adftest(regyii23.resid,'model','ARD','lags',setup.adflag);
[~,resyii2(6,4),resyii2(5,4)] = adftest(regyii24.resid,'model','ARD','lags',setup.adflag);
[~,resyii2(6,5),resyii2(5,5)] = adftest(regyii25.resid,'model','ARD','lags',setup.adflag);
[~,resyii2(6,6),resyii2(5,6)] = adftest(regyii26.resid,'model','ARD','lags',setup.adflag);
[~,resyii2(6,7),resyii2(5,7)] = adftest(regyii27.resid,'model','ARD','lags',setup.adflag);
[~,resyii2(6,8),resyii2(5,8)] = adftest(regyii28.resid,'model','ARD','lags',setup.adflag);

Corr_eii2 = [autocorr(regyii21.resid,'NumLags',3) autocorr(regyii22.resid,'NumLags',3) autocorr(regyii23.resid,'NumLags',3) autocorr(regyii24.resid,'NumLags',3) autocorr(regyii25.resid,'NumLags',3) ...
             autocorr(regyii26.resid,'NumLags',3) autocorr(regyii27.resid,'NumLags',3) autocorr(regyii28.resid,'NumLags',3)];
resyii2(1:3,:) = Corr_eii2(2:end,:);
resyii2(7,:)  = log(0.5)./log(resyii2(1,:));

%% Cointegration regressions, yields + pi and c
resypc  = NaN(7,8);
regypc1 = nwest(yc(:,1),[ones(size(yc,1),1) taui tauc],12);
regypc2 = nwest(yc(:,2),[ones(size(yc,1),1) taui tauc],12);
regypc3 = nwest(yc(:,3),[ones(size(yc,1),1) taui tauc],12);
regypc4 = nwest(yc(:,4),[ones(size(yc,1),1) taui tauc],12);
regypc5 = nwest(yc(:,5),[ones(size(yc,1),1) taui tauc],12);
regypc6 = nwest(yc(:,6),[ones(size(yc,1),1) taui tauc],12);
regypc7 = nwest(yc(:,7),[ones(size(yc,1),1) taui tauc],12);
regypc8 = nwest(yc(:,8),[ones(size(yc,1),1) taui tauc],12);

resypc(4,:) = [regypc1.rsqr regypc2.rsqr regypc3.rsqr regypc4.rsqr regypc5.rsqr regypc6.rsqr regypc7.rsqr regypc8.rsqr];

[~,resypc(6,1),resypc(5,1)] = adftest(regypc1.resid,'model','ARD','lags',setup.adflag);
[~,resypc(6,2),resypc(5,2)] = adftest(regypc2.resid,'model','ARD','lags',setup.adflag);
[~,resypc(6,3),resypc(5,3)] = adftest(regypc3.resid,'model','ARD','lags',setup.adflag);
[~,resypc(6,4),resypc(5,4)] = adftest(regypc4.resid,'model','ARD','lags',setup.adflag);
[~,resypc(6,5),resypc(5,5)] = adftest(regypc5.resid,'model','ARD','lags',setup.adflag);
[~,resypc(6,6),resypc(5,6)] = adftest(regypc6.resid,'model','ARD','lags',setup.adflag);
[~,resypc(6,7),resypc(5,7)] = adftest(regypc7.resid,'model','ARD','lags',setup.adflag);
[~,resypc(6,8),resypc(5,8)] = adftest(regypc8.resid,'model','ARD','lags',setup.adflag);

Corr_epc = [autocorr(regypc1.resid,'NumLags',3) autocorr(regypc2.resid,'NumLags',3) autocorr(regypc3.resid,'NumLags',3) autocorr(regypc4.resid,'NumLags',3) autocorr(regypc5.resid,'NumLags',3) ...
            autocorr(regypc6.resid,'NumLags',3) autocorr(regypc7.resid,'NumLags',3) autocorr(regypc8.resid,'NumLags',3)];
resypc(1:3,:) = Corr_epc(2:end,:);
resypc(7,:)  = log(0.5)./log(resypc(1,:));

%% Level and slope detrending
regLp  = nwest(PC(:,1),[ones(size(PC,1),1) taui],12);
regLpc = nwest(PC(:,1),[ones(size(PC,1),1) taui tauc],12);
regLt  = nwest(PC(:,1),[ones(size(PC,1),1) tauL],12);

regSc  = nwest(PC(:,2),[ones(size(PC,1),1) tauc],12);
regSpc = nwest(PC(:,2),[ones(size(PC,1),1) taui tauc],12);
regSt  = nwest(PC(:,2),[ones(size(PC,1),1) tauS],12);

plot(1:size(PC,1),PC(:,1),1:size(PC,1),regLp.yhat,1:size(PC,1),regLpc.yhat,1:size(PC,1),regLt.yhat)
plot(1:size(PC,1),PC(:,2),1:size(PC,1),regSc.yhat,1:size(PC,1),regSpc.yhat,1:size(PC,1),regSt.yhat)

regdLp  = nwest(diff(PC(:,1)),[ones(size(PC,1)-1,1) diff(taui)],12);
regdLpc = nwest(diff(PC(:,1)),[ones(size(PC,1)-1,1) diff(taui) diff(tauc)],12);

regdSc  = nwest(diff(PC(:,2)),[ones(size(PC,1)-1,1) diff(tauc)],12);
regdSpc = nwest(diff(PC(:,2)),[ones(size(PC,1)-1,1) diff(taui) diff(tauc)],12);

regdSt  = nwest(diff(PC(:,2)),[ones(size(PC,1)-1,1) diff(tauS)],12);

%% compare i star to LW
LW = xlsread('LW.xlsx');

regLW = nwest(LW(:,1)+taui(1:3:end)*100,[ones(size(LW,1),1) regshort.yhat(1:3:end)*100],0)

corr([regshort.yhat(1:3:end)*100 LW(:,1)+taui(1:3:end)*100])

yhatLW = [ones(size(regshort.yhat,1),1) regshort.yhat*100]*regLW.beta