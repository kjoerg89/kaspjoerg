
function out = BootstrapRegimeRegressions(data,setup)

%% Prepare data
[T,n] = size(data.yieldsOut(2:end,2:end));
mats  = data.yieldsOut(1,2:end);
macro = data.macro(1:end-setup.h,:);
y     = NaN(T-setup.h,n-1);
xSPR  = NaN(T-setup.h,n-1);
dummy = data.dummy(1:end-setup.h,:);
V = cov(data.yieldsOut(2:end,2:end)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,~,~] = pcacov(R); W = W'; PCy = data.yieldsOut(2:end,2:end)*W'; PCy(:,2) = -PCy(:,2); 
for i = 1:n-1
    y(:,i)    = -0*9*macro(1:end,end)/100 -1*mats(i)/12*data.yieldsOut(2+setup.h:end,1+i) + mats(i+1)/12*data.yieldsOut(2:end-setup.h,2+i) - setup.h/12*data.yieldsOut(2:end-setup.h,2);
    if setup.spread == 0
        xSPR(:,i) = (data.yieldsOut(2:end-setup.h,2+i)-data.yieldsOut(2:end-setup.h,2));
    elseif setup.spread == 1
        xSPR(:,i) = ((mats(i+1)*data.yieldsOut(2:end-setup.h,2+i)-mats(i)*data.yieldsOut(2:end-setup.h,1+i))/setup.h-data.yieldsOut(2:end-setup.h,2));
    elseif setup.spread == 2
        xSPR(:,i) = PCy(1:end-setup.h,2);
    end
end

%% Combine data
z = [y xSPR macro dummy];
z(setup.exclude,:) = [];

T = size(z,1)+setup.h;

%% Bootstrap
zBoot =block_bootstrap(z,setup.w,4*setup.B); % 4*setup.B is a big number to make sure we have enough in case we reject some samples

bettaSPR   = NaN(4+size(setup.macro,2),n-1,setup.B);
bettaSPR0  = NaN(2,n-1,setup.B);
b         = 1; 
idx       = 0;
while b <= setup.B
    idx       = idx + 1;
    if idx == 4*setup.B
        crash
    end
    
    % Unfold data
    z_tmp      = zBoot(:,:,idx);
    y_Boot     = z_tmp(:,1:n-1);
    xSPR_Boot  = z_tmp(:,n:2*(n-1));
    macro_Boot = z_tmp(:,2*(n-1)+1:end-1);
    if setup.BootNull == 1
        dummy_Boot = dummy(:,1); % (2:end,1) 
    else
        dummy_Boot = z_tmp(:,end);
    end
    
    % Test for number of lower bound dates in bootstrap sample
    ind = sum(dummy_Boot) >= setup.minObsZLB;
    ind = ind + (sum(1-dummy_Boot) >= setup.minObsZLB);
    if ind == 2
        for i = 1:n-1
            % Spread regression
            y = y_Boot(:,i);
            X = [ones(T-setup.h,1) xSPR_Boot(:,i) ...
                 dummy_Boot.*ones(T-setup.h,1) dummy_Boot.*xSPR_Boot(:,i) macro_Boot(:,setup.macro)];
            if any(isnan(y)) || any(any(isnan(X)))
                selectY = ~isnan(y);
                selectX = min(~isnan(X),[],2);
                y = y(selectY.*selectX == 1,1);
                X = X(selectY.*selectX == 1,:);
            end
            bettaSPR(:,i,b)  = (X'*X)\(X'*y);
            bettaSPR0(:,i,b) = (X(:,1:2)'*X(:,1:2))\(X(:,1:2)'*y);
        end
        b = b + 1;
        if mod(b,50) == 0
            disp(['Number of iterations so far =',num2str(b)]);
        end
    end
end

%% Saving output
out.bettaSPR_SE    = std(bettaSPR,0,3);
out.bettaSPR_025   = prctile(bettaSPR,2.5,3);
out.bettaSPR_050   = prctile(bettaSPR,5,3);
out.bettaSPR_950   = prctile(bettaSPR,95,3);
out.bettaSPR_975   = prctile(bettaSPR,97.5,3);

out.bettaSPR0_SE   = std(bettaSPR0,0,3);
out.bettaSPR0_025  = prctile(bettaSPR0,2.5,3);
out.bettaSPR0_050  = prctile(bettaSPR0,5,3);
out.bettaSPR0_950  = prctile(bettaSPR0,95,3);
out.bettaSPR0_975  = prctile(bettaSPR0,97.5,3);

end