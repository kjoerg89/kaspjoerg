
function out = RegimeRegressions(data,setup)

dummy = data.dummy;
mats  = data.yieldsOut(1,2:end);
[T,n] = size(data.yieldsOut(2:end,2:end));
macro = data.macro;
V = cov(data.yieldsOut(2:end,2:end)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,~,~] = pcacov(R); W = W'; PCy = data.yieldsOut(2:end,2:end)*W'; PCy(:,2) = -PCy(:,2); 

%% Yield Spread Regression
bettaSPR     = zeros(4+size(setup.macro,2),n-1);
bettaSPR_SE  = zeros(4+size(setup.macro,2),n-1);
bettaSPR0    = zeros(2,n-1);
bettaSPR0_SE = zeros(2,n-1);
for i = 1:n-1
   y = -0*9*macro(1:end-setup.h,end)/100 -1*mats(i)/12*data.yieldsOut(2+setup.h:end,1+i) + mats(i+1)/12*data.yieldsOut(2:end-setup.h,2+i) - setup.h/12*data.yieldsOut(2:end-setup.h,2);
   if setup.spread == 0
       X = [ones(T-setup.h,1) (data.yieldsOut(2:end-setup.h,2+i)-data.yieldsOut(2:end-setup.h,2)) ...
            dummy(1:end-setup.h,1).*ones(T-setup.h,1) dummy(1:end-setup.h,1).*(data.yieldsOut(2:end-setup.h,2+i)-data.yieldsOut(2:end-setup.h,2)) macro(1:end-setup.h,setup.macro)];
   elseif setup.spread == 1
       X = [ones(T-setup.h,1) ((mats(i+1)*data.yieldsOut(2:end-setup.h,2+i)-mats(i)*data.yieldsOut(2:end-setup.h,1+i))/setup.h-data.yieldsOut(2:end-setup.h,2)) ...
            dummy(1:end-setup.h,1).*ones(T-setup.h,1) dummy(1:end-setup.h,1).*((mats(i+1)*data.yieldsOut(2:end-setup.h,2+i)-mats(i)*data.yieldsOut(2:end-setup.h,1+i))/setup.h-data.yieldsOut(2:end-setup.h,2)) macro(1:end-setup.h,setup.macro)];
   elseif setup.spread == 2
       X = [ones(T-setup.h,1) PCy(1:end-setup.h,2) ...
            dummy(1:end-setup.h,1).*ones(T-setup.h,1) dummy(1:end-setup.h,1).*PCy(1:end-setup.h,2) macro(1:end-setup.h,setup.macro)];
   end
   y(setup.exclude,:) = [];
   X(setup.exclude,:) = [];
   if any(isnan(y)) || any(any(isnan(X)))
        selectY = ~isnan(y);
        selectX = min(~isnan(X),[],2);
        y = y(selectY.*selectX == 1,1);
        X = X(selectY.*selectX == 1,:);
   end 
   
   outSPR  = nwest(y,X,round(setup.h*1.5));
   outSPR0 = nwest(y,X(:,1:2),round(setup.h*1.5));
   
   bettaSPR(:,i)     = outSPR.beta;
   bettaSPR_SE(:,i)  = outSPR.beta./outSPR.tstat;
   bettaSPR0(:,i)    = outSPR0.beta;
   bettaSPR0_SE(:,i) = outSPR0.beta./outSPR0.tstat;
   
   [outSPR0.rsqr outSPR.rsqr outSPR.rsqr/outSPR0.rsqr]
end

% figure(1)
% hold on;
% scatter(100*X(dummy(1:353)==1,2),100*y(dummy(1:353)==1,1),6.0,'red','filled')
% scatter(100*X(dummy(1:353)==0,2),100*y(dummy(1:353)==0,1),6.0,'black','filled')
% xlim([-1 4.5])
% ylim([-25 30])
% legend('ZLB','No ZLB','Location','NorthWest')

%% Save output
out.bettaSPR     = bettaSPR;
out.bettaSPR_SE  = bettaSPR_SE;
out.bettaSPR0    = bettaSPR0;
out.bettaSPR0_SE = bettaSPR0_SE;

end