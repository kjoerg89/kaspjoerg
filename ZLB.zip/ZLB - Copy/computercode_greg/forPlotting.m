
close all; clear; clc; addpath(genpath(pwd)); 

%% Figure 1: Standard CS-regressions
load('yspr0h12null1m.mat')

figure(1);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [outBoot.bettaSPR0_025(2,:) fliplr(outBoot.bettaSPR0_975(2,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,outOLS.bettaSPR0(2,:),'-k','LineWidth',0.8);
plot(1.5:10.5,0*(1.5:10.5),':k')
xlim([1.75 10])
ylim([-2 5]);
yticks([-2:1:5])
xlabel('Maturity in years');
box off;
legend([h2 h1],'\beta_1^{(n)}','95% Confidence Interval','Location','NorthWest')
legend('boxoff')
saveas(gcf,'fig1.png')

clear;

%% Figure 2: Modified CS-regressions
load('yspr0h12null1m.mat');

figure(2)
subplot(2,1,1);
hold on;
plot(2:10,outOLS.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,outOLS.bettaSPR(2,:)+outOLS.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(1.5:10.5,0*(1.5:10.5),':k')
xlim([1.75 10])
ylim([-2 12])
yticks([-2:2:12])
box off;
legend('i_t \geq 1%','i_t < 1%','Location','NorthWest')
legend('boxoff')

subplot(2,1,2);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [outBoot.bettaSPR_025(4,:) fliplr(outBoot.bettaSPR_975(4,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,outOLS.bettaSPR(4,:),'-k','LineWidth',0.8);
plot(1.5:10.5,0*(1.5:10.5),':k')
xlim([1.75 10])
ylim([-2 12]);
yticks([-2:2:12])
xlabel('Maturity in years');
box off;
legend([h2 h1],'Difference','95% Confidence Interval','Location','NorthWest')
legend('boxoff')
saveas(gcf,'fig2.png')

clear;

%% Figure 3: Modified CS-regressions, bootstrapped under the null
load('yspr0h12null0m.mat');

figure(3);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [outBoot.bettaSPR_025(4,:) fliplr(outBoot.bettaSPR_975(4,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,outOLS.bettaSPR(4,:),'-k','LineWidth',0.8);
plot(1.5:10.5,0*(1.5:10.5),':k')
xlim([1.75 10])
ylim([-6 8]);
yticks([-6:2:8])
xlabel('Maturity in years');
box off;
legend([h2 h1],'Difference','95% Confidence Interval','Location','NorthWest')
legend('boxoff')
saveas(gcf,'fig3.png')

clear;

%% Figure 4: Modified CS-regressions, robustness results
x  = 0;
y  = 0;
yn = 0;
yp = 0;

load('yspr0h3null1m.mat')

x  = [x x(end)+1];
y  = [y outOLS.bettaSPR(end,end)];
yn = [yn outBoot.bettaSPR_025(end,end)-outOLS.bettaSPR(end,end)];
yp = [yp outBoot.bettaSPR_975(end,end)-outOLS.bettaSPR(end,end)];
clearvars -except x y yn yp;

load('yspr0h6null1m.mat')

x  = [x x(end)+1];
y  = [y outOLS.bettaSPR(end,end)];
yn = [yn outBoot.bettaSPR_025(end,end)-outOLS.bettaSPR(end,end)];
yp = [yp outBoot.bettaSPR_975(end,end)-outOLS.bettaSPR(end,end)];
clearvars -except x y yn yp;

load('yspr1h12null1m.mat')

x  = [x x(end)+1];
y  = [y outOLS.bettaSPR(end,end)];
yn = [yn outBoot.bettaSPR_025(end,end)-outOLS.bettaSPR(end,end)];
yp = [yp outBoot.bettaSPR_975(end,end)-outOLS.bettaSPR(end,end)];
clearvars -except x y yn yp;

load('yspr2h12null1m.mat')

x  = [x x(end)+1];
y  = [y abs(outOLS.bettaSPR(end,end))];
yn = [yn abs(outBoot.bettaSPR_025(end,end)-outOLS.bettaSPR(end,end))];
yp = [yp abs(outBoot.bettaSPR_975(end,end)-outOLS.bettaSPR(end,end))];
clearvars -except x y yn yp;

load('yspr0h12null1m12.mat')

x  = [x x(end)+1];
y  = [y outOLS.bettaSPR(4,end)];
yn = [yn outBoot.bettaSPR_025(4,end)-outOLS.bettaSPR(4,end)];
yp = [yp outBoot.bettaSPR_975(4,end)-outOLS.bettaSPR(4,end)];
clearvars -except x y yn yp;

load('yspr0h12null1m4.mat')

x  = [x x(end)+1];
y  = [y outOLS.bettaSPR(4,end)];
yn = [yn outBoot.bettaSPR_025(4,end)-outOLS.bettaSPR(4,end)];
yp = [yp outBoot.bettaSPR_975(4,end)-outOLS.bettaSPR(4,end)];
clearvars -except x y yn yp;

load('yspr0h12null1m8.mat')

x  = [x x(end)+1];
y  = [y outOLS.bettaSPR(4,end)];
yn = [yn outBoot.bettaSPR_025(4,end)-outOLS.bettaSPR(4,end)];
yp = [yp outBoot.bettaSPR_975(4,end)-outOLS.bettaSPR(4,end)];
clearvars -except x y yn yp;

% load('special.mat')
% 
% x  = [x x(end)+1];
% y  = [y outOLS.bettaSPR(4,end)];
% yn = [yn outBoot.bettaSPR_025(4,end)-outOLS.bettaSPR(4,end)];
% yp = [yp outBoot.bettaSPR_975(4,end)-outOLS.bettaSPR(4,end)];
% clearvars -except x y yn yp;

x  = x(2:end);
y  = y(2:end);
yp = yp(2:end);
yn = yn(2:end);

figure(4);
hold on;
h1 = errorbar(x,y,yn,yp,'.k','LineWidth',1,'MarkerSize',1,'CapSize',15);
h2 = plot(x,y,'sk','LineWidth',1,'MarkerSize',10);
plot(0.75:0.25:7.25,0.*(0.75:0.25:7.25),':k');
xlim([0.75 7.25])
ylim([-2 14])
yticks([-2:2:14])
xticks([1:7])
xticklabels({'h = 3','h = 6','fwd spread','PC_2','spread + macro','spread + i*','survey forecasts'})
xtickangle(-45)
title('Difference in \beta_1^{(10)} between sub-samples')
box off;
legend([h2 h1],'Difference','95% Confidence Interval','Location','NorthWest');
legend('boxoff');
saveas(gcf,'fig4.png')

clear;

%% Figure 5: SRM CS-regressions
load('yspr0h12null1m.mat');
extra = load('modelNum2_parsi4_includeSurveyON0.mat');

figure(5)
subplot(2,1,1);
hold on;
plot(2:10,outOLS.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,outOLS.bettaSPR(2,:)+outOLS.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,extra.momentsModel.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8);
plot(2:10,extra.momentsModel.bettaSPR(2,:)+extra.momentsModel.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8);
xlim([1.75 10])
ylim([0 12])
yticks([-2:2:12])
box off;
legend('Data: i_t \geq 1%','Data: i_t < 1%','Model: i_t \geq 1%','Model: i_t < 1%','Location','NorthWest')
legend('boxoff')

subplot(2,1,2);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [outBoot.bettaSPR_025(4,:) fliplr(outBoot.bettaSPR_975(4,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,outOLS.bettaSPR(4,:),'-k','LineWidth',0.8);
h3 = plot(2:10,extra.momentsModel.bettaSPR(4,:),'sk','LineWidth',0.8);
xlim([1.75 10])
ylim([-2 12]);
yticks([-2:2:12])
xlabel('Maturity in years');
box off;
legend([h2 h1 h3],'Difference','95% Confidence Interval','Model','Location','NorthWest')
legend('boxoff')
saveas(gcf,'fig5.png')

clear;

%% Figure 6: Survey fit
x = datenum(1990,1:365,1);

extra0 = load('modelNum2_parsi4_includeSurveyON0.mat');
extra1 = load('modelNum2_parsi4_includeSurveyON1_stdSurvey0.0075.mat');
extra2 = load('modelNum2_parsi0_includeSurveyON1_stdSurvey0.0075.mat');

figure(6)
subplot(3,2,1);
hold on;
plot(x(~isnan(extra0.surveys(1,:))),100*extra0.surveys(1,~isnan(extra0.surveys(1,:))),'+k','MarkerSize',3,'LineWidth',0.5);
plot(x(~isnan(extra0.surveys(1,:))),100*extra0.outQML.outFilter.yhat(7,~isnan(extra0.surveys(1,:))),'ok','MarkerSize',3,'LineWidth',0.5);
datetick('x');
axis('tight');
ylim([0 8])
yticks([0:2:8])
ylabel('Percent')
title('5-year')
box off;

subplot(3,2,2);
hold on;
plot(x(~isnan(extra0.surveys(2,:))),100*extra0.surveys(2,~isnan(extra0.surveys(2,:))),'+k','MarkerSize',3,'LineWidth',0.5);
h4 = plot(x(~isnan(extra0.surveys(2,:))),100*extra0.outQML.outFilter.yhat(8,~isnan(extra0.surveys(2,:))),'ok','MarkerSize',3,'LineWidth',0.5);
datetick('x');
axis('tight');
ylim([0 8])
yticks([0:2:8])
ylabel('Percent')
title('5-to-10-year')
box off;

subplot(3,2,3);
hold on;
plot(x(~isnan(extra0.surveys(1,:))),100*extra0.surveys(1,~isnan(extra0.surveys(1,:))),'+k','MarkerSize',3,'LineWidth',0.5);
plot(x(~isnan(extra0.surveys(1,:))),100*extra1.outQML.outFilter.yhat(7,~isnan(extra0.surveys(1,:))),'sk','MarkerSize',3,'LineWidth',0.5);
datetick('x');
axis('tight');
ylim([0 8])
yticks([0:2:8])
ylabel('Percent')
title('5-year')
box off;

subplot(3,2,4);
hold on;
plot(x(~isnan(extra0.surveys(2,:))),100*extra0.surveys(2,~isnan(extra0.surveys(2,:))),'+k','MarkerSize',3,'LineWidth',0.5);
h3 = plot(x(~isnan(extra0.surveys(2,:))),100*extra1.outQML.outFilter.yhat(8,~isnan(extra0.surveys(2,:))),'sk','MarkerSize',3,'LineWidth',0.5);
datetick('x');
axis('tight');
ylim([0 8])
yticks([0:2:8])
ylabel('Percent')
title('5-to-10-year')
box off;

subplot(3,2,5);
hold on;
plot(x(~isnan(extra0.surveys(1,:))),100*extra0.surveys(1,~isnan(extra0.surveys(1,:))),'+k','MarkerSize',3,'LineWidth',0.5);
plot(x(~isnan(extra0.surveys(1,:))),100*extra2.outQML.outFilter.yhat(7,~isnan(extra0.surveys(1,:))),'^k','MarkerSize',3,'LineWidth',0.5);
datetick('x');
axis('tight');
ylim([0 8])
yticks([0:2:8])
ylabel('Percent')
title('5-year')
box off;

subplot(3,2,6);
hold on;
h1 = plot(x(~isnan(extra0.surveys(2,:))),100*extra0.surveys(2,~isnan(extra0.surveys(2,:))),'+k','MarkerSize',3,'LineWidth',0.5);
h2 = plot(x(~isnan(extra0.surveys(2,:))),100*extra2.outQML.outFilter.yhat(8,~isnan(extra0.surveys(2,:))),'^k','MarkerSize',3,'LineWidth',0.5);
datetick('x');
axis('tight');
ylim([0 8])
yticks([0:2:8])
ylabel('Percent')
title('5-to-10-year')
box off;
h = legend([h1 h4 h3 h2],'Surveys','SRM (no survey)','SRM (survey)','R-SRM','Location','South','Orientation','Horizontal');
legend('boxoff');
pos = get(h,'Position');
set(h,'Position',pos + [-0.03 0.825 0 0]);
saveas(gcf,'fig6.png')

clear;

%% Figure 7: In-sample fit
extra0 = load('modelNum2_parsi4_includeSurveyON0.mat');
extra1 = load('modelNum2_parsi4_includeSurveyON1_stdSurvey0.0075.mat');
extra2 = load('modelNum2_parsi0_includeSurveyON1_stdSurvey0.0075.mat');

y0 = std(extra0.setup.dataAll(:,1+extra0.setup.matSelect/3)'-extra0.outQML.outFilter.yhat(1:6,:),0,2)*10000;
y1 = std(extra1.setup.dataAll(:,1+extra0.setup.matSelect/3)'-extra1.outQML.outFilter.yhat(1:6,:),0,2)*10000;
y2 = std(extra2.setup.dataAll(:,1+extra0.setup.matSelect/3)'-extra2.outQML.outFilter.yhat(1:6,:),0,2)*10000;

figure(7);
hold on;
b = bar([y0 y1 y2]);
b(1).FaceColor = [0 0 0];
b(2).FaceColor = [0.5 0.5 0.5];
b(3).FaceColor = [0.8 0.8 0.8];
ylim([0 10])
yticks([0:2:10])
xticklabels({'3-month','1-year','3-year','5-year','7-year','10-year'});
ylabel('Basis points')
box off;
legend('SRM (no survey)','SRM (survey)','R-SRM','Location','North','Orientation','Horizontal');
legend('boxoff');
saveas(gcf,'fig7.png')

%% Figure 8: SRM CS-regressions, survey
load('yspr0h12null1m.mat');
extra = load('modelNum2_parsi4_includeSurveyON1_stdSurvey0.0075.mat');

figure(8)
subplot(2,1,1);
hold on;
plot(2:10,outOLS.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,outOLS.bettaSPR(2,:)+outOLS.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,extra.momentsModel.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8);
plot(2:10,extra.momentsModel.bettaSPR(2,:)+extra.momentsModel.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8);
xlim([1.75 10])
ylim([0 12])
yticks([-2:2:12])
box off;
legend('Data: i_t \geq 1%','Data: i_t < 1%','Model: i_t \geq 1%','Model: i_t < 1%','Location','NorthWest')
legend('boxoff')

subplot(2,1,2);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [outBoot.bettaSPR_025(4,:) fliplr(outBoot.bettaSPR_975(4,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,outOLS.bettaSPR(4,:),'-k','LineWidth',0.8);
h3 = plot(2:10,extra.momentsModel.bettaSPR(4,:),'sk','LineWidth',0.8);
xlim([1.75 10])
ylim([-2 12]);
yticks([-2:2:12])
xlabel('Maturity in years');
box off;
legend([h2 h1 h3],'Difference','95% Confidence Interval','Model','Location','NorthWest')
legend('boxoff')
saveas(gcf,'fig8.png')

clear;

%% Figure 9: SRM CS-regressions, survey
load('yspr0h12null1m.mat');
extra = load('modelNum2_parsi0_includeSurveyON1_stdSurvey0.0075.mat');

figure(9)
subplot(2,1,1);
hold on;
plot(2:10,outOLS.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,outOLS.bettaSPR(2,:)+outOLS.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,extra.momentsModel.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8);
plot(2:10,extra.momentsModel.bettaSPR(2,:)+extra.momentsModel.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8);
xlim([1.75 10])
ylim([0 12])
yticks([-2:2:12])
box off;
legend('Data: i_t \geq 1%','Data: i_t < 1%','Model: i_t \geq 1%','Model: i_t < 1%','Location','NorthWest')
legend('boxoff')

subplot(2,1,2);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [outBoot.bettaSPR_025(4,:) fliplr(outBoot.bettaSPR_975(4,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,outOLS.bettaSPR(4,:),'-k','LineWidth',0.8);
h3 = plot(2:10,extra.momentsModel.bettaSPR(4,:),'sk','LineWidth',0.8);
xlim([1.75 10])
ylim([-2 12]);
yticks([-2:2:12])
xlabel('Maturity in years');
box off;
legend([h2 h1 h3],'Difference','95% Confidence Interval','Model','Location','NorthWest')
legend('boxoff')
saveas(gcf,'fig9.png')

clear;

%% Figure 10: term premia
x = datenum(1990,1:365,1);

extra0 = load('modelNum2_parsi4_includeSurveyON0.mat');
extra1 = load('modelNum2_parsi4_includeSurveyON1_stdSurvey0.0075.mat');
extra2 = load('modelNum2_parsi0_includeSurveyON1_stdSurvey0.0075.mat');

figure(10)
hold on;
inBetweenx = [(x(168)-(x(168)-x(167))/2):1:(x(168)+(x(169)-x(168))/2) fliplr((x(168)-(x(168)-x(167))/2):1:(x(168)+(x(169)-x(168))/2))];
inBetweeny = [-2*ones(1,size(inBetweenx,2)/2) fliplr(6*ones(1,size(inBetweenx,2)/2))];
fill(inBetweenx,inBetweeny,[0.95 0.95 0.95],'LineStyle','none');
inBetweenx = [(x(226)-(x(226)-x(225))/2):1:(x(329)+(x(330)-x(329))/2) fliplr((x(226)-(x(226)-x(225))/2):1:(x(329)+(x(330)-x(329))/2))];
inBetweeny = [-2*ones(1,size(inBetweenx,2)/2) fliplr(6*ones(1,size(inBetweenx,2)/2))];
fill(inBetweenx,inBetweeny,[0.95 0.95 0.95],'LineStyle','none');
inBetweenx = [(x(363)-(x(363)-x(362))/2):1:x(end) fliplr((x(363)-(x(363)-x(362))/2):1:x(end))];
inBetweeny = [-2*ones(1,size(inBetweenx,2)/2) fliplr(6*ones(1,size(inBetweenx,2)/2))];
fill(inBetweenx,inBetweeny,[0.95 0.95 0.95],'LineStyle','none');
%h1 = plot(x,100*extra0.yieldTP.termPremia(:,end),'-k','MarkerSize',4,'LineWidth',0.8);
h2 = plot(x,100*extra1.yieldTP.termPremia(:,end),'-+k','MarkerSize',3,'LineWidth',0.8,'color',[0.4 0.4 0.4]);
h3 = plot(x,100*extra2.yieldTP.termPremia(:,end),'-*k','MarkerSize',3,'LineWidth',0.8,'color',[0.75 0.75 0.75]);
datetick('x');
axis('tight');
ylim([-2 4])
yticks([-2:2:4])
ylabel('Percent')
set(gca,'Layer','top')
box off;
h = legend([h2 h3],'SRM','R-SRM','Location','North','Orientation','Horizontal');
pos = get(h,'Position');
set(h,'Position',pos + [0 0.095 0 0]);
legend('boxoff')
saveas(gcf,'fig10.png')

clear;

%% Figure 11: unconditional moments
extra0 = load('modelNum2_parsi4_includeSurveyON0.mat');
extra1 = load('modelNum2_parsi4_includeSurveyON1_stdSurvey0.0075.mat');
extra2 = load('modelNum2_parsi0_includeSurveyON1_stdSurvey0.0075.mat');

figure(11)
subplot(2,1,1)
hold on;
h1 = bar([100*extra0.momentsModel.meanYield' 100*extra1.momentsModel.meanYield' 100*extra2.momentsModel.meanYield']);
h1(1).FaceColor = [0.35 0.35 0.35];
h1(2).FaceColor = [0.60 0.60 0.60];
h1(3).FaceColor = [0.85 0.85 0.85];
plot(1:10,100*extra0.momentsData.meanYield,'-sk','MarkerSize',6,'MarkerFaceColor','k','LineWidth',1.0);
xlim([0 11])
xticks([1:10])
xlabel('Maturity in years');
ylim([0 10])
yticks([2:2:10])
ylabel('Percent')
title('Unconditional Mean')
box off;

subplot(2,1,2)
hold on;
h1 = bar([100*extra0.momentsModel.stdYield' 100*extra1.momentsModel.stdYield' 100*extra2.momentsModel.stdYield']);
h1(1).FaceColor = [0.35 0.35 0.35];
h1(2).FaceColor = [0.60 0.60 0.60];
h1(3).FaceColor = [0.85 0.85 0.85];
h2 = plot(1:10,100*extra0.momentsData.stdYield,'-sk','MarkerSize',6,'MarkerFaceColor','k','LineWidth',1.0);
xlim([0 11])
xticks([1:10])
xlabel('Maturity in years');
ylim([1 4])
yticks([2:1:4])
ylabel('Percent')
title('Unconditional Standard Deviation')
box off;
h = legend([h2 h1],'Data','SRM (no survey)','SRM (survey)','R-SRM','Location','North','Orientation','Horizontal');
pos = get(h,'Position');
set(h,'Position',pos + [0 0.475 0 0]);
legend('boxoff')
saveas(gcf,'figmom.png')

clear;

%% Figure 12: conditional moments
extra0 = load('modelNum2_parsi4_includeSurveyON0.mat');
extra1 = load('modelNum2_parsi4_includeSurveyON1_stdSurvey0.0075.mat');
extra2 = load('modelNum2_parsi0_includeSurveyON1_stdSurvey0.0075.mat');

x1 = [mean(extra1.momentsModel.zlbDuration) mean(extra1.momentsModel.zlbDuration < 24) mean(extra1.momentsModel.zlbDuration >= 24 & extra1.momentsModel.zlbDuration < 48 ) mean(extra1.momentsModel.zlbDuration >= 48)]';
x2 = [mean(extra2.momentsModel.zlbDuration) mean(extra2.momentsModel.zlbDuration < 24) mean(extra2.momentsModel.zlbDuration >= 24 & extra2.momentsModel.zlbDuration < 48 ) mean(extra2.momentsModel.zlbDuration >= 48)]';

figure(12)
subplot(3,1,1)
hold on;
h1 = bar([100*extra1.momentsModel.meanYield_regime1' 100*extra2.momentsModel.meanYield_regime1']);
h1(1).FaceColor = [0.60 0.60 0.60];
h1(2).FaceColor = [0.85 0.85 0.85];
xlim([0 11])
xticks([1:10])
xlabel('Maturity in years');
ylim([0 10])
yticks([2:2:10])
ylabel('Percent')
title('Conditional Mean: Non-ZLB Regime')
box off;

subplot(3,1,2)
hold on;
h1 = bar([100*extra1.momentsModel.meanYield_regime2' 100*extra2.momentsModel.meanYield_regime2']);
h1(1).FaceColor = [0.60 0.60 0.60];
h1(2).FaceColor = [0.85 0.85 0.85];
xlim([0 11])
xticks([1:10])
xlabel('Maturity in years');
ylim([1 4])
yticks([2:1:4])
ylabel('Percent')
title('Conditional Mean: ZLB Regime')
box off;
h = legend([h1],'SRM','R-SRM','Location','NorthWest','Orientation','Horizontal');
pos = get(h,'Position');
set(h,'Position',pos + [0 0.315 0 0]);
legend('boxoff')

subplot(3,1,3)
hold on;
%h1 = bar([x1 x2]);
[AX,h1,h2] = plotyy(1,[x1(1) x2(1)],2:4,[x1(2:end) x2(2:end)],'bar','bar');
xline(1.5,'--k');
h1(1).FaceColor = [0.60 0.60 0.60];
h1(2).FaceColor = [0.85 0.85 0.85];
h2(1).FaceColor = [0.60 0.60 0.60];
h2(2).FaceColor = [0.85 0.85 0.85];
xlim([0.5 4.5])
xticks([1:4])
xticklabels({'Mean duration','0-2 years','2-4 years','4+ years'});
set(AX(1),'ylim',[0 40])
set(AX(2),'ylim',[0 1])
set(AX(1),'ytick',[0:10:40])
set(AX(2),'ytick',[0:0.25:1])
ylabel(AX(1),'Months')
ylabel(AX(2),'Probability')
title('Duration of ZLB Episodes')
box off;
saveas(gcf,'figmom_cond.png')

clear;

%% Figure 13(?): Forced SRM regressions
load('yspr0h12null1m.mat');
extra = load('SMM.mat');

figure(13)
subplot(2,1,1);
hold on;
plot(2:10,outOLS.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,outOLS.bettaSPR(2,:)+outOLS.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,extra.momSim(5,2:end),'^k','MarkerSize',4,'LineWidth',0.8);
plot(2:10,extra.momSim(5,2:end)+extra.momSim(6,2:end),'ok','MarkerSize',4,'LineWidth',0.8);
xlim([1.75 10])
ylim([0 12])
yticks([-2:2:12])
box off;
legend('Data: i_t \geq 1%','Data: i_t < 1%','Model: i_t \geq 1%','Model: i_t < 1%','Location','NorthWest')
legend('boxoff')

subplot(2,1,2);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [outBoot.bettaSPR_025(4,:) fliplr(outBoot.bettaSPR_975(4,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,outOLS.bettaSPR(4,:),'-k','LineWidth',0.8);
h3 = plot(2:10,extra.momSim(6,2:end),'sk','LineWidth',0.8);
xlim([1.75 10])
ylim([-2 12]);
yticks([-2:2:12])
xlabel('Maturity in years');
box off;
legend([h2 h1 h3],'Difference','95% Confidence Interval','Model','Location','NorthWest')
legend('boxoff')
saveas(gcf,'figForced.png')

clear;

%% Figure 14(?): Forced model, moments
extra = load('SMM.mat');

figure(14)
subplot(2,2,3);
hold on;
inBetweenx = [1:10 fliplr(1:10)];
inBetweeny = [100*extra.bootprc_meanNOZLB(1,:) fliplr(100*extra.bootprc_meanNOZLB(2,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(1:10,100*extra.momData(1,:),'-k','LineWidth',0.8);
h3 = plot(1:10,100*extra.momSim(1,:),'sk','LineWidth',0.8);
xlim([0.75 10])
ylim([0 15]);
yticks([0:5:15])
title('Means: Away from the ZLB');
xlabel('Maturity in years');
ylabel('Percent')
box off;

subplot(2,2,4);
hold on;
inBetweenx = [1:10 fliplr(1:10)];
inBetweeny = [100*extra.bootprc_meanZLB(1,:) fliplr(100*extra.bootprc_meanZLB(2,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(1:10,100*extra.momData(2,:),'-k','LineWidth',0.8);
h3 = plot(1:10,100*extra.momSim(2,:),'sk','LineWidth',0.8);
xlim([0.75 10])
ylim([0 15]);
yticks([0:5:15])
title('Means: At the ZLB');
xlabel('Maturity in years');
ylabel('Percent')
box off;

subplot(2,2,1);
hold on;
inBetweenx = [1:10 fliplr(1:10)];
inBetweeny = [100*extra.bootprc_stdNOZLB(1,:) fliplr(100*extra.bootprc_stdNOZLB(2,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(1:10,100*extra.momData(3,:),'-k','LineWidth',0.8);
h3 = plot(1:10,100*extra.momSim(3,:),'sk','LineWidth',0.8);
xlim([0.75 10])
ylim([0 3]);
yticks([0:1:3])
title('Std: Away from the ZLB');
xlabel('Maturity in years');
ylabel('Percent')
box off;

subplot(2,2,2);
hold on;
inBetweenx = [1:10 fliplr(1:10)];
inBetweeny = [100*extra.bootprc_stdZLB(1,:) fliplr(100*extra.bootprc_stdZLB(2,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(1:10,100*extra.momData(4,:),'-k','LineWidth',0.8);
h3 = plot(1:10,100*extra.momSim(4,:),'sk','LineWidth',0.8);
xlim([0.75 10])
ylim([0 3]);
yticks([0:1:3])
title('Std: At the ZLB');
xlabel('Maturity in years');
ylabel('Percent')
box off;
legend([h2 h1 h3],'Difference','95% Confidence Interval','Model','Location','NorthWest')
legend('boxoff')
saveas(gcf,'figForced_moms.png')

clear;

%% Figure 15(?): UK + Germany
UK = load('yspr0h12null1m_UK.mat');
GE = load('yspr0h12null1m_GE.mat');
x  = datenum(1990,1:365,1);

figure(15)
subplot(3,2,1);
hold on;
plot(x,UK.loadData.policyRate,'-k','LineWidth',0.8);
plot(x,zeros(size(UK.loadData.policyRate)),':k','LineWidth',0.6);
datetick('x');
axis('tight');
ylim([-1 15])
yticks([0:2:14])
ylabel('Percent')
box off;
legend('Policy Rate','Location','NorthEast','Orientation','Horizontal');
legend('boxoff')
title('UK')

subplot(3,2,2);
hold on;
plot(x,GE.loadData.policyRate,'-k','LineWidth',0.8);
plot(x,zeros(size(GE.loadData.policyRate)),':k','LineWidth',0.6);
datetick('x');
axis('tight');
ylim([-1 9])
yticks([0:2:8])
ylabel('Percent')
box off;
legend('Policy Rate','Location','NorthEast','Orientation','Horizontal');
legend('boxoff')
title('Germany')

subplot(3,2,3);
hold on;
plot(2:10,UK.outOLS.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,UK.outOLS.bettaSPR(2,:)+UK.outOLS.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(1.5:10.5,0*(1.5:10.5),':k')
xlim([1.75 10])
ylim([-2 12])
yticks([-2:2:12])
box off;
legend('i_t \geq 1%','i_t < 1%','Location','NorthWest')
legend('boxoff')

subplot(3,2,5);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [UK.outBoot.bettaSPR_025(4,:) fliplr(UK.outBoot.bettaSPR_975(4,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,UK.outOLS.bettaSPR(4,:),'-k','LineWidth',0.8);
plot(1.5:10.5,0*(1.5:10.5),':k')
xlim([1.75 10])
ylim([-2 12]);
yticks([-2:2:12])
xlabel('Maturity in years');
box off;
legend([h2 h1],'Difference','95% Confidence Interval','Location','NorthWest')
legend('boxoff')

subplot(3,2,4);
hold on;
plot(2:10,GE.outOLS.bettaSPR(2,:),'^k','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(2:10,GE.outOLS.bettaSPR(2,:)+GE.outOLS.bettaSPR(4,:),'ok','MarkerSize',4,'LineWidth',0.8,'MarkerEdgeColor',[0.5 0.5 0.5]);
plot(1.5:10.5,0*(1.5:10.5),':k')
xlim([1.75 10])
ylim([-2 12])
yticks([-2:2:12])
box off;
legend('i_t \geq 1%','i_t < 1%','Location','NorthWest')
legend('boxoff')

subplot(3,2,6);
hold on;
inBetweenx = [2:10 fliplr(2:10)];
inBetweeny = [GE.outBoot.bettaSPR_025(4,:) fliplr(GE.outBoot.bettaSPR_975(4,:))];
h1 = fill(inBetweenx,inBetweeny,[0.9 0.9 0.9],'LineStyle','none');
h2 = plot(2:10,GE.outOLS.bettaSPR(4,:),'-k','LineWidth',0.8);
plot(1.5:10.5,0*(1.5:10.5),':k')
xlim([1.75 10])
ylim([-2 12]);
yticks([-2:2:12])
xlabel('Maturity in years');
box off;
legend([h2 h1],'Difference','95% Confidence Interval','Location','NorthWest')
legend('boxoff')
saveas(gcf,'figUKGE.png')

clear;

%% Figure ??: survey forecasting errors
x = datenum(1990,1:365,1);

extra = xlsread('surveyplot.xls');

figure(16);
hold on;
plot(x,extra(:,end),'-k','MarkerSize',3,'LineWidth',1.3);
for i = 1:floor(size(x,2)/12)
    plot(x(12*(i-1)+1:3:12*i+1),extra(12*(i-1)+1,1:end-1),':k','MarkerSize',3,'LineWidth',1.3);
end
datetick('x');
axis('tight');
ylim([0 10])
yticks([0:2:10])
ylabel('Percent')
box off;
h = legend('10-year yield','Blue Chip Consensus Expectation, 10-year yield','Location','NorthEast','Orientation','Vertical');
legend('boxoff')
saveas(gcf,'surveyplot.png')

clear;