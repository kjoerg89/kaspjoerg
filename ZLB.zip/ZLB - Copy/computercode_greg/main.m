
% Kasper J�rgensen, August 2021

clear; close all; clc; addpath(genpath(pwd));

rng(159); % for reproducability

%% User input
%setup.break       = [231:364]; % Germany
%setup.break       = [228:337 364]; % Canada
%setup.break       = [231:364]; % UK
setup.break       = [168 225:329 362:364]; % regime-switching [225:329 362:364], permanent break [225:364]
setup.exclude     = []; % December 2003 [168], December 2003 and new data [168 312:353]
setup.h           = 12; % Data file has yields with maturities in intervals of 3-months, so h must be a multiple of 3
setup.w           = 24; % Block length for the bootstrap
setup.B           = 5000; % Number of bootstrap samples
setup.minObsZLB   = 50; % Minimum number of observations in each subsample, only matters if bootstrapping under the alternative
setup.BootNull    = 0;  % 1 for bootstrapping under the null, 0 for bootstrapping under the alternative
setup.spread      = 0;  % 0 for yield spread, 1 for forward spread, 2 for second principal component
setup.macro       = []; % pick rows of macro vars to include: [INFL_trend CFNAI I* I*xDummy ffr FG LSAP 10-year_forecast 9-year_forecast] 

%% Load data
%load('loadDataYields_May2020GE.mat');
%load('loadDataYields_May2020CA.mat');
%load('loadDataYields_May2020UK.mat');
load('loadDataYields_May2020.mat'); 
loadData.yieldsOut = loadData.yieldsOut(:,[1==1 ismember(loadData.yieldsOut(1,2:end),setup.h:setup.h:120)]);
loadData.dummy     = zeros(size(loadData.yieldsOut,1)-1,1);
loadData.dummy(setup.break+1,1) = ones(size(setup.break,2),1);
loadData.macro     = xlsread('macrovars.xls'); loadData.macro(:,3) = fillmissing(loadData.macro(:,3),'linear');
loadData.macro     = [loadData.macro(:,1:3) loadData.macro(:,3).*loadData.dummy loadData.macro(:,4:end-1) [loadData.macro(1:end-12,end-1);NaN(12,1)]];

%% Run regressions
outOLS  = RegimeRegressions(loadData,setup);

%% Run bootstrap
outBoot = BootstrapRegimeRegressions(loadData,setup);

save(['yspr' num2str(setup.spread) 'h' num2str(setup.h) 'null' num2str(1-setup.BootNull) 'm' num2str(setup.macro(:))' ''])
%save(['yspr' num2str(setup.spread) 'h' num2str(setup.h) 'null' num2str(1-setup.BootNull) 'm' num2str(setup.macro(:))' '_UK'])
%save(['yspr' num2str(setup.spread) 'h' num2str(setup.h) 'null' num2str(1-setup.BootNull) 'm' num2str(setup.macro(:))' '_CA'])
%save(['yspr' num2str(setup.spread) 'h' num2str(setup.h) 'null' num2str(1-setup.BootNull) 'm' num2str(setup.macro(:))' '_GE'])
