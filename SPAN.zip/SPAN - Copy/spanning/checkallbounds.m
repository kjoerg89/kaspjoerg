
function out = checkallbounds(lbounds,lbounds_names,ubounds,ubounds_names,params,params_names)

% check lower bounds
for i = 1:size(lbounds,2)
    if lbounds(i) > params(find(strcmp(lbounds_names{i},params_names)))
        out = 1;
        return;
    end
end

% check upper bounds
for i = 1:size(ubounds,2)
    if ubounds(i) < params(find(strcmp(ubounds_names{i},params_names)))
        out = 1;
        return;
    end
end

out = 0;

end