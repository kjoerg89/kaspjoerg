
function [muq,phiq,mup,phip,sigma,d0,d1,sigy,pai0,pai1,sigpai] = modelmatrices(params,params_names,calibrate,calibrate_names,nx,mats,usp)

% combine names and values
names = [params_names calibrate_names];
vals  = [params calibrate];

% create matrices to fill
muq    = NaN(nx,1);
mup    = NaN(nx,1);
phiq   = NaN(nx,nx);
phip   = NaN(nx,nx);
sigma  = NaN(nx,nx);
d1     = NaN(1,nx);
pai1   = NaN(1,nx);
sigpai = NaN(1,nx+1);

% assign matrix values from estimated and calibrated values
d0   = vals(find(strcmp(names,'d0')));
pai0 = vals(find(strcmp(names,'pai0')));
sigu = vals(find(strcmp(names,'sigu')))/1200;
sigsr6m = vals(find(strcmp(names,'sigsr6m')))/1200;
sigsr1y = vals(find(strcmp(names,'sigsr1y')))/1200;
sigsrlr = vals(find(strcmp(names,'sigsrlr')))/1200;
sigspai1y = vals(find(strcmp(names,'sigspai1y')))/1200;
sigspailr = vals(find(strcmp(names,'sigspailr')))/1200;
for i = 1:nx
    muq(i,1)    = vals(find(strcmp(names,['muq' num2str(i)])));
    mup(i,1)    = vals(find(strcmp(names,['mup' num2str(i)])));
    d1(1,i)     = vals(find(strcmp(names,['d1' num2str(i)])));
    pai1(1,i)   = vals(find(strcmp(names,['pai1' num2str(i)])));
    sigpai(1,i) = vals(find(strcmp(names,['sigpai' num2str(i)])));
    for j = 1:nx
        phiq(i,j) = vals(find(strcmp(names,['phiq' num2str(i) num2str(j)])));
        phip(i,j) = vals(find(strcmp(names,['phip' num2str(i) num2str(j)])));
        if i == j
            phiq(i,j) = phiq(i,j)*100;
            phip(i,j) = phip(i,j)*100;
        end
        if i >= j
            sigma(i,j) = vals(find(strcmp(names,['sigma' num2str(i) num2str(j)])));
        else
            sigma(i,j) = 0;
        end
    end
end
sigpai(1,end) = vals(find(strcmp(names,['sigpai0'])));

% construct measurement error variance matrix
sigy = diag([repmat(sigu,1,size(mats,2)) sigsr6m sigsr1y sigsrlr 0 sigspai1y sigspailr]);

if usp
    % calculate gamma vector
    phiq22 = phiq(usp+1:end,usp+1:end);
    phiq21 = phiq(usp+1:end,1:usp);
    v = (phiq22 - eye(size(phiq22,1)))\phiq21; % note: this trick imposes unspanned unit root factors under Q
    
    d1(1,1:usp) = d1(1,usp+1:end)*v;
end
    
end