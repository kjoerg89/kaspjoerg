
function [an,bn] = anbn(muq,phiq,sigma,d0,d1,mats)

% initialize an and bn
bn = NaN(max(mats),size(muq,1));
an = NaN(max(mats),1);

% calculate an and bn recursively
for i = 1:max(mats)
    if i == 1
        bn(i,:) = - d1;
        an(i,:) = - d0;
    else
        bn(i,:) = bn(i-1,:)*phiq - d1;
        an(i,:) = an(i-1,:) + bn(i-1,:)*muq + .5*bn(i-1,:)*(sigma*sigma')*bn(i-1,:)' - d0;
    end
end
   
bn = -bn(mats,:)./repmat(mats',1,size(muq,2));
an = -an(mats,:)./mats';

end