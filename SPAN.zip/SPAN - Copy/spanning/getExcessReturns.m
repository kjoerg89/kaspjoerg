
function xr = getExcessReturns(params,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                                          ubounds,ubounds_names,data,mats,nx,usp)

% check bounds
if checkallbounds(lbounds,lbounds_names,ubounds,ubounds_names,params,params_names)
    xr = [];
    return;
end

% get model matrices
[muq,phiq,mup,phip,sigma,d0,d1,sigy,pai0,pai1,sigpai] = modelmatrices(params,params_names,calibrate,calibrate_names,nx,mats,usp);

% get yield factor loadings
[an,bn] = anbn(muq,phiq,sigma,d0,d1,mats);

% get short rate and inflation survey loadings
[an_sr,bn_sr,an_spai,bn_spai] = ansbns(mup,phip,an(1),bn(1,:),pai0,pai1);

% construct state space matrices
[a,b,sigy,mu,phi,sigx] = statespacematrices(an,bn,an_sr,bn_sr,an_spai,bn_spai,sigy,mup,phip,pai0,pai1,sigma,sigpai);

% calculate state estimates, covariances and loglik by kalman filter
[states,covar,loglik,loglikpp] = kalmanfilter(a,b,sigy,mu,phi,sigx,data);

%% Calculate 2-yr and 10-yr expected excess returns
[an,bn] = anbn(muq,phiq,sigma,d0,d1,3:3:120);

xr2  = 8*an(8,1) + 8*bn(8,:)*states(:,1:nx)' - 7*an(7,1) - 7*bn(7,:)*(eye(nx) + phip + phip^2)*mup - 7*bn(7,:)*phip^3*states(:,1:nx)' - an(1,1) - bn(1,:)*states(:,1:nx)';
xr10 = 40*an(end,1) + 40*bn(end,:)*states(:,1:nx)' - 39*an(end-1,1) - 39*bn(end-1,:)*(eye(nx) + phip + phip^2)*mup - 39*bn(end-1,:)*phip^3*states(:,1:nx)' - an(1,1) - bn(1,:)*states(:,1:nx)';

xr = 1200*[xr2' xr10'];
end