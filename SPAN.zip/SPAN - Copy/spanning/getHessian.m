
function H = getHessian(paramsOpt,calibrate,params_names,calibrate_names, ...
                lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal,epsSE,factor)

loglik    = loglikfunc(paramsOpt,calibrate,params_names,calibrate_names, ...
                       lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal);            
            
H = NaN(size(paramsOpt,2),size(paramsOpt,2));
for i = 1:size(paramsOpt,2)
    for j = 1:i
        if i==j
            epsi        = factor*min(abs(paramsOpt(i)*0.005),epsSE);
            paramspp    = paramsOpt;
            paramsmm    = paramsOpt;
            paramspp(i) = paramspp(i) + epsi; 
            paramsmm(i) = paramsmm(i) - epsi;
            loglikpp    = loglikfunc(paramspp,calibrate,params_names,calibrate_names, ...
                                             lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal);
            loglikmm    = loglikfunc(paramsmm,calibrate,params_names,calibrate_names, ...
                                             lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal);
            
            H(i,j) = (loglikpp - 2*loglik + loglikmm)/(epsSE^2);
        else
            epsi        = factor*min(abs(paramsOpt(i)*0.005),epsSE);
            epsj        = factor*min(abs(paramsOpt(j)*0.005),epsSE);
            paramspp    = paramsOpt;
            paramspm    = paramsOpt;
            paramsmp    = paramsOpt;
            paramsmm    = paramsOpt;
            paramspp(i) = paramspp(i) + epsi;
            paramspp(j) = paramspp(j) + epsj;
            paramspm(i) = paramspm(i) + epsi;
            paramspm(j) = paramspm(j) - epsj;
            paramsmp(i) = paramsmp(i) - epsi;
            paramsmp(j) = paramsmp(j) + epsj;
            paramsmm(i) = paramsmm(i) - epsi;
            paramsmm(j) = paramsmm(j) - epsj;
            loglikpp    = loglikfunc(paramspp,calibrate,params_names,calibrate_names, ...
                                             lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal);
            loglikpm    = loglikfunc(paramspm,calibrate,params_names,calibrate_names, ...
                                             lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal);                             
            loglikmp    = loglikfunc(paramsmp,calibrate,params_names,calibrate_names, ...
                                             lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal);
            loglikmm    = loglikfunc(paramsmm,calibrate,params_names,calibrate_names, ...
                                             lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal);
            
            H(i,j) = (loglikpp - loglikpm - loglikmp + loglikmm)/(4*epsSE^2);
            H(j,i) = H(i,j);
        end
    end
end

end