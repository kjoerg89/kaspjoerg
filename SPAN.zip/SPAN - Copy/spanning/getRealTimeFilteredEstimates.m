
function rt = getRealTimeFilteredEstimates(params,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                    ubounds,ubounds_names,data,mats,nx,usp)

% check bounds
if checkallbounds(lbounds,lbounds_names,ubounds,ubounds_names,params,params_names)
    rt = [];
    return;
end

% get model matrices
[muq,phiq,mup,phip,sigma,d0,d1,sigy,pai0,pai1,sigpai] = modelmatrices(params,params_names,calibrate,calibrate_names,nx,mats,usp);

% get yield factor loadings
[an,bn] = anbn(muq,phiq,sigma,d0,d1,mats);

% get short rate and inflation survey loadings
[an_sr,bn_sr,an_spai,bn_spai] = ansbns(mup,phip,an(1),bn(1,:),pai0,pai1);

% construct state space matrices
[a,b,sigy,mu,phi,sigx] = statespacematrices(an,bn,an_sr,bn_sr,an_spai,bn_spai,sigy,mup,phip,pai0,pai1,sigma,sigpai);

% calculate state estimates, covariances and loglik by kalman filter
[states,covar,loglik,loglikpp] = kalmanfilter(a(1:8,1),b(1:8,1:nx),sigy(1:8,1:8),mu(1:nx,1),phi(1:nx,1:nx),sigx(1:nx,1:nx),data(:,1:8));

%% Calculate real-time filtered estimates
istar  = 1200*(a(11,1) + b(11,1:nx)*states');
pistar = 1200*(a(end,1) + b(end,1:nx)*states');
rstar  = istar - pistar;

istarSE  = NaN(size(data,1),1);
pistarSE = NaN(size(data,1),1);
rstarSE  = NaN(size(data,1),1);
for t = 1:size(data,1)
    istarSE(t,1)  = b(11,1:nx)*covar(:,:,t)*b(11,1:nx)';
    pistarSE(t,1) = b(14,1:nx)*covar(:,:,t)*b(14,1:nx)';
    rstarSE(t,1)  = (b(11,1:nx)-b(14,1:nx))*covar(:,:,t)*(b(11,1:nx)-b(14,1:nx))';
end

rt.star   = [istar' pistar' rstar'];
rt.starSE = [istarSE pistarSE rstarSE]; 

end