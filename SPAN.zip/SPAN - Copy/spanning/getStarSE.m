
function starSE = getStarSE(paramsOpt,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                            ubounds,ubounds_names,data,mats,nx,nomreal,mc,model,usp)

rng(159); % for reproducability
                        
T = size(data,1);

istarSEi  = NaN(T,mc);
pistarSEi = NaN(T,mc);
rstarSEi  = NaN(T,mc);
m = 1;
while m <= mc
    % draw from asymptotic distribution of param vector
    paramsi = (paramsOpt')'; % + 0*diag(sqrt(diag(SE)))*randn(size(paramsOpt')) + 0*chol(SE)*randn(size(paramsOpt')))';
    
    % calculate state and covar of state estimates by kalman filter
    modeli  = model_output(paramsi,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                           ubounds,ubounds_names,data,mats,nx,usp);
                       
    if modeli.loglik ~= 10^100
        for t = 1:size(data,1)
            % calculate state vector standard error
            xSEi  = modeli.covar(:,:,t) + (modeli.states(t,:)-model.states(t,:))'*(modeli.states(t,:)-model.states(t,:));
            
            % calculate i* standard error
            istarSEi(t,m)  = modeli.b(end-3,:)*xSEi*modeli.b(end-3,:)';
            
            % calculate pi* standard error
            pistarSEi(t,m) = modeli.b(end,:)*xSEi*modeli.b(end,:)';
            
            % calculate r* standard error
            rstarSEi(t,m)  = (modeli.b(end-3,:)-modeli.b(end,:))*xSEi*(modeli.b(end-3,:)-modeli.b(end,:))';
        end
        m = m+1;
    end
end

starSE.istarSE  = mean(istarSEi,2);
starSE.pistarSE = mean(pistarSEi,2);
starSE.rstarSE  = mean(rstarSEi,2);
        
end