
function [a,b,sigy,mu,phi,sigx] = statespacematrices(an,bn,an_sr,bn_sr,an_spai,bn_spai,sigy,mup,phip,pai0,pai1,sigma,sigpai)

nx = size(bn,2);

% construct measurement matrices
a    = [an;an_sr;0;an_spai];
b    = [bn zeros(size(bn,1),1);bn_sr zeros(size(bn_sr,1),1);zeros(1,nx) 1;bn_spai zeros(size(bn_spai,1),1)];
sigy = sigy;

% construct transition matrices
mu   = [mup;pai0];
phi  = [phip zeros(nx,1);pai1 0];
sigx = [sigma zeros(nx,1);sigpai];

end