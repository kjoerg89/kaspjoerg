function printToScreen(vector_input)
vector(1,:) = vector_input(:);
ncols      = size(vector,2);
if ncols > 5
    lines = floor(ncols/5);
    for i = 1:lines
        for ll=1+5*(i-1):5*i
            if ll == 5*i
                fprintf('%16.12f  \n',vector(ll));
            else
                fprintf('%16.12f  ',vector(ll));
            end
        end
    end
    for ll=lines*5+1:ncols
        if ll == ncols
            fprintf('%16.12f  \n',vector(ll));
        else
            fprintf('%16.12f  ',vector(ll));
        end
    end
else
    for ll=1:ncols
        if ll == ncols
            fprintf('%16.12f  \n',vector(ll));
        else
            fprintf('%16.12f  ',vector(ll));
        end
    end
end


end

