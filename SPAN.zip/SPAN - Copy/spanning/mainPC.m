
close all; clear; clc; addpath(genpath(pwd));

%% Pull data
data = readtable('dtsm_data.csv'); data = data{:,2:9}/1200; 

V = cov(data); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = data*Wy'; 

data = 100*PC(:,1:3);

clearvars -except data Wy

%% Get starting values
params = [-0.056054185908    0.037221387249    0.014822123418    0.919847654073    0.051152977735 ...  
           0.006669551044   -0.119893916539    1.023473409330    0.018867552265    0.025527858601 ... 
           0.070605927592    0.828446024183    0.007535615533   -0.004538191494   -0.001162687853 ... 
           0.048930712340    0.017323032046   -0.007895857607    0.028884087593   -0.014527930104 ... 
          -0.000780861820   -0.000810789381    0.010395181144    0.000323199717];  

%% Run optimizer
options   = optimset('Display','iter','MaxIter',1D4,'MaxFunEvals',1D8,'TolFun',1e-10,'TolX',1e-10); % optimizer settings
paramsOpt = fmincon(@loglikfuncPC,params,[],[],[],[],[],[],[],options,data);                                     

[loglik,states,covar] = loglikfuncPC(paramsOpt,data);

printToScreen(paramsOpt);

%% Long run expectations
mu  = paramsOpt(1:3)';
phi = reshape(paramsOpt(4:12),3,3)';
g   = paramsOpt(13:15)';

Pinf = inv(eye(3)-phi)*(mu + g*states(:,1)');
invW = inv(Wy);

y3inf = 12*invW(1,1:3)*Pinf;

plot(1:460,y3inf)

corr(states)