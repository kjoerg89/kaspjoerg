
function [states,covar,loglik,loglikpp] = kalmanfilter(a,b,sigy,mu,phi,sigx,data)

nx = size(mu,1);
T  = size(data,1);

% get initial mean and covar
if any(abs(eig(phi)) >= 1)
    xu = zeros(nx,1);
    cu = 3*(sigx*sigx');
else
    xu = zeros(nx,1);
    cu = 3*(sigx*sigx');
%     xu = inv(eye(nx)-phi)*mu;
%     cu = inv(eye(nx)-phi'*phi)*(sigx*sigx');
end

states = NaN(T,nx);
covar  = NaN(nx,nx,T);
loglik = NaN(T,1);
for t = 1:T
    idx = ~isnan(data(t,:))';

    % prediction step
    xp = mu + phi*xu;
    cp = phi*cu*phi' + (sigx*sigx');
    
    % update step
    S  = b(idx,:)*cp*b(idx,:)' + sigy(idx,idx)*sigy(idx,idx)';
    e  = data(t,idx)' - a(idx,1) - b(idx,:)*xp;
    K  = cp*b(idx,:)'*inv(S);
    xu = xp + K*e;
    %cu = (eye(nx) - K*b(idx,:))*cp; % may be unstable
    G  = eye(size(cp)) - K*b(idx,:); % Joseph-form, supposedly more stable
    cu = G*cp*G' + K*(sigy(idx,idx)*sigy(idx,idx)')*K';
    ll = -.5*(e'*inv(S)*e + log(det(S)));
    
    % report
    states(t,:)  = xu';
    covar(:,:,t) = cu;
    loglik(t,1)  = ll;
end

loglikpp = -loglik(7:end,1); 
loglik   = -mean(loglik(7:end,1));
    
end