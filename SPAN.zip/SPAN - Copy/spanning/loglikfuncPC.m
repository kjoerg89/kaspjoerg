
function [loglik,states,covar,loglikpp] = loglikfuncPC(params,data)

[T,N] = size(data);

aux = zeros(N,N);
ii  = 0;
for i = 1:N
    for j = 1:N
        if i>=j
            ii = ii + 1;
            aux(i,j) = params(N*(N+3)+ii);
        end
    end
end

% construct state space matrices
a    = zeros(N,1);
b    = [zeros(N,1) eye(N)];
sigy = zeros(N,N);

mu   = [0; params(1:N)'];
phi  = [1 zeros(1,N); params(N*(N+1)+1:N*(N+2))' reshape(params(N+1:N*(N+1)),N,N)];
sigx = [1 zeros(1,N); params(N*(N+2)+1:N*(N+3))' aux];

% calculate loglikelihood by Kalman filter
[states,covar,loglik,loglikpp] = kalmanfilter(a,b,sigy,mu,phi,sigx,data);

end
