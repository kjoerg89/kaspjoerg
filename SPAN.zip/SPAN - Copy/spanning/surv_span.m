
%% surveys
close all; clear; clc; addpath(genpath(pwd));

data = readtable('dtsm_data.csv'); data = data{:,2:end};
data = data(~any(isnan(data),2),:);

V = cov(data(:,1:8)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = data(:,1:8)*Wy'; PC = PC(:,1:3);

clearvars -except data PC
clc

regsi = nwest(data(:,11),[ones(size(data,1),1) PC],0);
regsp = nwest(data(:,14),[ones(size(data,1),1) PC],0);

ARi   = [regsi.rsqr; regsi.sige; autocorr(regsi.resid,'NumLags',3)]
ARp   = [regsp.rsqr; regsp.sige; autocorr(regsp.resid,'NumLags',3)]

%% 3fac_RW0_USP0_nom
close all; clear; clc; addpath(genpath(pwd));

A = load('res_3fac_RW0_USP0_ZLB25.mat'); y = A.model.yfit(:,11);

data = readtable('dtsm_data.csv'); data = data{:,2:end};

V = cov(data(:,1:8)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = data(:,1:8)*Wy'; PC = PC(:,1:3);

clearvars -except PC y

regi  = nwest(y,[ones(size(y,1),1) PC],0);
regdi = nwest(diff(y),[ones(size(diff(y),1),1) diff(PC)],0);

ARi   = [regi.rsqr; regi.sige; autocorr(regi.resid,'NumLags',3)]
ARdi  = [regdi.rsqr; regdi.sige; autocorr(regdi.resid,'NumLags',3)]

%% 4fac_RW0_USP0_nom
close all; clear; clc; addpath(genpath(pwd));

A = load('res_4fac_RW0_USP0_ZLB25.mat'); y = A.model.yfit(:,11);

data = readtable('dtsm_data.csv'); data = data{:,2:end};

V = cov(data(:,1:8)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = data(:,1:8)*Wy'; PC = PC(:,1:3);

clearvars -except PC y

regi  = nwest(y,[ones(size(y,1),1) PC],0);
regdi = nwest(diff(y),[ones(size(diff(y),1),1) diff(PC)],0);

ARi   = [regi.rsqr; regi.sige; autocorr(regi.resid,'NumLags',3)]
ARdi  = [regdi.rsqr; regdi.sige; autocorr(regdi.resid,'NumLags',3)]

%% 4fac_RW1_USP0_nom
close all; clear; clc; addpath(genpath(pwd));

A = load('res_4fac_RW1_USP0_ZLB25.mat'); y = A.model.yfit(:,11);

data = readtable('dtsm_data.csv'); data = data{:,2:end};

V = cov(data(:,1:8)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = data(:,1:8)*Wy'; PC = PC(:,1:3);

clearvars -except PC y

regi  = nwest(y,[ones(size(y,1),1) PC],0);
regdi = nwest(diff(y),[ones(size(diff(y),1),1) diff(PC)],0);

ARi   = [regi.rsqr; regi.sige; autocorr(regi.resid,'NumLags',3)]
ARdi  = [regdi.rsqr; regdi.sige; autocorr(regdi.resid,'NumLags',3)]

%% 4fac_RW1_USP1_nom
close all; clear; clc; addpath(genpath(pwd));

A = load('res_4fac_RW1_USP1_ZLB25.mat'); y = A.model.yfit(:,11);

data = readtable('dtsm_data.csv'); data = data{:,2:end};

V = cov(data(:,1:8)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,P,E] = pcacov(R); Wy = W'; PC = data(:,1:8)*Wy'; PC = PC(:,1:3);

clearvars -except PC y

regi  = nwest(y,[ones(size(y,1),1) PC],0);
regdi = nwest(diff(y),[ones(size(diff(y),1),1) diff(PC)],0);

ARi   = [regi.rsqr; regi.sige; autocorr(regi.resid,'NumLags',3)]
ARdi  = [regdi.rsqr; regdi.sige; autocorr(regdi.resid,'NumLags',3)]
