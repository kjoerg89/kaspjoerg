
function [an_sr,bn_sr,an_spai,bn_spai] = ansbns(mup,phip,an,bn,pai0,pai1)

a  = NaN(132,1);
b  = NaN(132,size(phip,1));
ap = NaN(132,1);
bp = NaN(132,size(phip,1));

for i = 1:132
    if i == 1
        a(i)    = an + bn*mup;
        b(i,:)  = bn*phip;
        ap(i)   = pai0;
        bp(i,:) = pai1;
    else
        a(i)    = a(i-1) + bn*phip^(i-1)*mup;
        b(i,:)  = bn*phip^i;
        ap(i)   = ap(i-1) + pai1*phip^(i-2)*mup;
        bp(i,:) = pai1*phip^(i-1);
    end
end

an_sr   = [a(6,1); a(12,1); mean(a(73:end,1),1)];
bn_sr   = [b(6,:); b(12,:); mean(b(73:end,:),1)];
an_spai = [mean(ap(1:12,1)); mean(ap(73:end,1),1)];
bn_spai = [mean(bp(1:12,:),1); mean(bp(73:end,:),1)];

end