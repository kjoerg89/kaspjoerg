
function out = BootstrapStarSE(paramsOpt,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                               ubounds,ubounds_names,data,mats,nx,nomreal,mc,w,model,usp)
                           
%% Generate bootstrap samples
% Calculate innovations
epsx  = (model.states(2:end,:)' - repmat(model.mu,1,size(model.states,1)-1) - model.phi*model.states(1:end-1,:)')';
epsy  = (data' - repmat(model.a,1,size(data,1)) - model.b*model.states')';
eps   = [epsy(2:end,:) epsx];

% Calculate bootstrap innovations
epsB  = block_bootstrap(eps,w,mc);
epsxB = epsB(:,end-nx:end,:);
epsyB = epsB(:,1:end-nx-1,:);

% Calculate bootstrap data sets
dataBoot = NaN(size(data,1),size(data,2),mc);
for B = 1:mc
    for t = 1:size(data,1)
        if t == 1
            x = zeros(size(model.states,2),1);
            y = model.a + model.b*x;
        else
            x = model.mu + model.phi*x + epsxB(t-1,:,B)';
            y = model.a + model.b*x + epsyB(t-1,:,B)';
        end
        dataBoot(t,:,B) = y';
    end
end

%% Estimate params on each bootstrap sample
options    = optimset('Display','off','MaxIter',5D3,'MaxFunEvals',1D8,'TolFun',1e-10,'TolX',1e-10); % optimizer settings
paramsBoot = NaN(mc,size(paramsOpt,2));
for B = 1:mc
    if rem(B,25)==0
        disp(['Now running estimation for bootstrap sample number ' num2str(B) ' ...']);
    end
    
    params = fminsearch(@loglikfunc,paramsOpt,options,calibrate,params_names,calibrate_names, ...
                                             lbounds,lbounds_names,ubounds,ubounds_names,dataBoot(:,:,B),mats,nx,nomreal,usp);
    paramsBoot(B,:) = params;
end

%% Run kalman filter for each bootstrap params vector to facilitate calculating filter and params uncertainty
statesBootr  = NaN(size(data,1),mc);
statesBootpi = NaN(size(data,1),mc);
statesBooti  = NaN(size(data,1),mc);
covarBootr   = NaN(size(data,1),mc);
covarBootpi  = NaN(size(data,1),mc);
covarBooti   = NaN(size(data,1),mc);
for B = 1:mc
    % get model matrices
    [muq,phiq,mup,phip,sigma,d0,d1,sigy,pai0,pai1,sigpai] = modelmatrices(paramsBoot(B,:),params_names,calibrate,calibrate_names,nx,mats,usp);
    
    % get yield factor loadings
    [an,bn] = anbn(muq,phiq,sigma,d0,d1,mats);
    
    % get short rate and inflation survey loadings
    [an_sr,bn_sr,an_spai,bn_spai] = ansbns(mup,phip,an(1),bn(1,:),pai0,pai1);
    
    % construct state space matrices
    [a,b,sigy,mu,phi,sigx] = statespacematrices(an,bn,an_sr,bn_sr,an_spai,bn_spai,sigy,mup,phip,pai0,pai1,sigma,sigpai);
    
    % calculate state estimates and covariances by kalman filter
    [states,covar] = kalmanfilter(a,b,sigy,mu,phi,sigx,data);
    
    % Tag on zero loading on inflation
    bn_sr   = [bn_sr zeros(size(bn_sr,1),1)];
    bn_spai = [bn_spai zeros(size(bn_spai,1),1)];
    
    % calculate weighted states and covariances
    for t = 1:size(data,1)
        statesBootr(t,B)  = ((an_sr(end,:)-an_spai(end,:)) + (bn_sr(end,:)-bn_spai(end,:))*states(t,:)' - ...
                             (model.a(end-3)-model.a(end)) - (model.b(end-3,:)-model.b(end,:))*model.states(t,:)')^2;
        statesBootpi(t,B) = (an_spai(end,:) + bn_spai(end,:)*states(t,:)' - model.a(end,:) - model.b(end,:)*model.states(t,:)')^2;
        statesBooti(t,B)  = (an_sr(end,:) + bn_sr(end,:)*states(t,:)' - model.a(end-3,:) - model.b(end-3,:)*model.states(t,:)')^2;
        
        covarBootr(t,B)   = (bn_sr(end,:)-bn_spai(end,:))*covar(:,:,t)*(bn_sr(end,:)-bn_spai(end,:))';
        covarBootpi(t,B)  = bn_spai(end,:)*covar(:,:,t)*bn_spai(end,:)';
        covarBooti(t,B)   = bn_sr(end,:)*covar(:,:,t)*bn_sr(end,:)';
    end
end

%% Report the desired statistics
out.paramsBoot = paramsBoot;
out.rstarUnc_filter  = mean(covarBootr,2);
out.rstarUnc_params  = mean(statesBootr,2);
out.pistarUnc_filter = mean(covarBootpi,2);
out.pistarUnc_params = mean(statesBootpi,2);
out.istarUnc_filter  = mean(covarBooti,2);
out.istarUnc_params  = mean(statesBooti,2);
out.rstarUnc         = out.rstarUnc_filter + out.rstarUnc_params;
out.pistarUnc        = out.pistarUnc_filter + out.pistarUnc_params;
out.istarUnc         = out.istarUnc_filter + out.istarUnc_params;

end