
%% plot a few things

close all; clear; clc; addpath(genpath(pwd));

[y,m] = meshgrid((1983:2021)',(1:12));
dates = eomdate(y(:),m(:));
dates = dates(1:460);

figure(1)
hold on;
load('res_3fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*data(:,11),'ob');
plot(dates,model.yfit(:,11),'-k');
load('res_4fac_RW0_USP0_ZLB25.mat');
plot(dates,model.yfit(:,11),'-r');
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,model.yfit(:,11),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,model.yfit(:,11),'-g');
axis('tight')
ylim([0 10]);
dateaxis('x');
legend('Surveys','3fac,RW0,USP0','4fac,RW0,USP0','4fac,RW1,USP0','4fac,RW1,USP1');
legend('boxoff');
title('i* estimates');

figure(2);
hold on;
load('res_3fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*sqrt(starSE.istarSE),':k');
plot(dates,1200*sqrt(outBoot.istarUnc_filter),'--k');
plot(dates,1200*sqrt(outBoot.istarUnc),'-k');
load('res_4fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*sqrt(starSE.istarSE),':r');
plot(dates,1200*sqrt(outBoot.istarUnc_filter),'--r');
plot(dates,1200*sqrt(outBoot.istarUnc),'-r');
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,1200*sqrt(starSE.istarSE),':m');
plot(dates,1200*sqrt(outBoot.istarUnc_filter),'--m');
plot(dates,1200*sqrt(outBoot.istarUnc),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,1200*sqrt(starSE.istarSE),':g');
plot(dates,1200*sqrt(outBoot.istarUnc_filter),'--g');
plot(dates,1200*sqrt(outBoot.istarUnc),'-g');
axis('tight')
dateaxis('x');
legend('3fac,RW0,USP0, filter (no boot)','filter','filter+params',...
       '4fac,RW0,USP0, filter (no boot)','filter','filter+params',...
       '4fac,RW1,USP0, filter (no boot)','filter','filter+params',...
       '4fac,RW1,USP1, filter (no boot)','filter','filter+params');
legend('boxoff');
title('Decomposition of uncertainty about i*');

figure(3);
hold on;
load('res_3fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*sqrt(starSE.istarSE),'-k');
load('res_4fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*sqrt(starSE.istarSE),'-r');
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,1200*sqrt(starSE.istarSE),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,1200*sqrt(starSE.istarSE),'-g');
axis('tight')
dateaxis('x');
legend('3fac,RW0,USP0, filter (no boot)',...
       '4fac,RW0,USP0, filter (no boot)',...
       '4fac,RW1,USP0, filter (no boot)',...
       '4fac,RW1,USP1, filter (no boot)','Location','NorthWest');
legend('boxoff');
title('filter uncertainty (no bootstrap)');

figure(4);
hold on;
load('res_3fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*sqrt(outBoot.istarUnc_filter),'-k');
load('res_4fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*sqrt(outBoot.istarUnc_filter),'-r');
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,1200*sqrt(outBoot.istarUnc_filter),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,1200*sqrt(outBoot.istarUnc_filter),'-g');
axis('tight')
dateaxis('x');
legend('3fac,RW0,USP0, filter',...
       '4fac,RW0,USP0, filter',...
       '4fac,RW1,USP0, filter',...
       '4fac,RW1,USP1, filter','Location','NorthWest');
legend('boxoff');
title('filter uncertainty (bootstrap)');

figure(5);
hold on;
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,model.states(:,1),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,model.states(:,1),'-g');
axis('tight')
dateaxis('x');
legend('4fac,RW1,USP0',...
       '4fac,RW1,USP1','Location','NorthEast');
legend('boxoff');
title('Random walk factors');

figure(6)
subplot(1,2,1);
hold on;
load('res_3fac_RW0_USP0_ZLB25_real1.mat');
plot(dates,1200*(data(:,11)-data(:,end)),'ob');
plot(dates,model.yfit(:,11)-model.yfit(:,end),'-k');
load('res_4fac_RW0_USP0_ZLB25_real1.mat');
plot(dates,model.yfit(:,11)-model.yfit(:,end),'-r');
load('res_4fac_RW1_USP0_ZLB25_real1.mat');
plot(dates,model.yfit(:,11)-model.yfit(:,end),'-m');
load('res_4fac_RW2_USP0_ZLB25_real1.mat');
plot(dates,model.yfit(:,11)-model.yfit(:,end),'-g');
axis('tight')
ylim([-1 5]);
dateaxis('x');
legend('Surveys','3fac,RW0,USP0','4fac,RW0,USP0','4fac,RW1,USP0','4fac,RW2,USP0');
legend('boxoff');
title('r* estimates');

subplot(1,2,2);
hold on;
load('res_3fac_RW0_USP0_ZLB25_real1.mat');
plot(dates,1200*data(:,end),'ob');
plot(dates,model.yfit(:,end),'-k');
load('res_4fac_RW0_USP0_ZLB25_real1.mat');
plot(dates,model.yfit(:,end),'-r');
load('res_4fac_RW1_USP0_ZLB25_real1.mat');
plot(dates,model.yfit(:,end),'-m');
load('res_4fac_RW2_USP0_ZLB25_real1.mat');
plot(dates,model.yfit(:,end),'-g');
axis('tight')
ylim([-1 5]);
dateaxis('x');
legend('Surveys','3fac,RW0,USP0','4fac,RW0,USP0','4fac,RW1,USP0','4fac,RW2,USP0');
legend('boxoff');
title('pi* estimates');

figure(7);
subplot(1,2,1);
hold on;
load('USP0_l.mat');
plot(dates,1200*data(:,11),'ob');
plot(dates,model.yfit(:,11),'-k');
load('USP0_m.mat');
plot(dates,model.yfit(:,11),'-r');
load('USP0_h.mat');
plot(dates,model.yfit(:,11),'-m');
axis('tight')
ylim([0 10]);
dateaxis('x');
legend('Surveys','USP0 low','USP0 med','USP0 high');
legend('boxoff');
title('i* estimates, RW1 USP0');

subplot(1,2,2);
hold on;
load('USP1_l.mat');
plot(dates,1200*data(:,11),'ob');
plot(dates,model.yfit(:,11),'-k');
load('USP1_m.mat');
plot(dates,model.yfit(:,11),'-r');
load('USP1_h.mat');
plot(dates,model.yfit(:,11),'-m');
axis('tight')
ylim([0 10]);
dateaxis('x');
legend('Surveys','USP1 low','USP1 med','USP1 high');
legend('boxoff');
title('i* estimates, RW1 USP1');

figure(8);
subplot(1,2,1);
hold on;
load('res_3fac_RW0_USP0_ZLB25.mat');
plot(dates,xr(:,1),'-k');
load('res_4fac_RW0_USP0_ZLB25.mat');
plot(dates,xr(:,1),'-r');
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,xr(:,1),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,xr(:,1),'-g');
axis('tight')
dateaxis('x');
legend('3fac_RW0_USP0','4fac_RW0_USP0','4fac_RW1_USP0','4fac_RW1_USP1');
legend('boxoff');
title('2yr exp excess return');

subplot(1,2,2);
hold on;
load('res_3fac_RW0_USP0_ZLB25.mat');
plot(dates,xr(:,2),'-k');
load('res_4fac_RW0_USP0_ZLB25.mat');
plot(dates,xr(:,2),'-r');
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,xr(:,2),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,xr(:,2),'-g');
axis('tight')
dateaxis('x');
legend('3fac_RW0_USP0','4fac_RW0_USP0','4fac_RW1_USP0','4fac_RW1_USP1');
legend('boxoff');
title('10yr exp excess return');

figure(9);
hold on;
load('res_3fac_RW0_USP0_ZLB25.mat');
plot(dates,rt.star(:,1),'-k');
load('res_4fac_RW0_USP0_ZLB25.mat');
plot(dates,rt.star(:,1),'-r');
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,rt.star(:,1),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,rt.star(:,1),'-g');
axis('tight')
dateaxis('x');
legend('3fac_RW0_USP0','4fac_RW0_USP0','4fac_RW1_USP0','4fac_RW1_USP1');
legend('boxoff');
title('real-time filtered i* estimate');

figure(10);
hold on;
load('res_3fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*sqrt(rt.starSE(:,1)),'-k');
load('res_4fac_RW0_USP0_ZLB25.mat');
plot(dates,1200*sqrt(rt.starSE(:,1)),'-r');
load('res_4fac_RW1_USP0_ZLB25.mat');
plot(dates,1200*sqrt(rt.starSE(:,1)),'-m');
load('res_4fac_RW1_USP1_ZLB25.mat');
plot(dates,1200*sqrt(rt.starSE(:,1)),'-g');
axis('tight')
dateaxis('x');
legend('3fac_RW0_USP0','4fac_RW0_USP0','4fac_RW1_USP0','4fac_RW1_USP1');
legend('boxoff');
title('real-time filtered i* uncertainty');
