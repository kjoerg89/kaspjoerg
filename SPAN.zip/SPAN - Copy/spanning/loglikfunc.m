
function loglik = loglikfunc(params,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                    ubounds,ubounds_names,data,mats,nx,nomreal,usp)

% check bounds
if checkallbounds(lbounds,lbounds_names,ubounds,ubounds_names,params,params_names)
    loglik = 10^100;
    return;
end

% get model matrices
[muq,phiq,mup,phip,sigma,d0,d1,sigy,pai0,pai1,sigpai] = modelmatrices(params,params_names,calibrate,calibrate_names,nx,mats,usp);

% get yield factor loadings
[an,bn] = anbn(muq,phiq,sigma,d0,d1,mats);

% get short rate and inflation survey loadings
[an_sr,bn_sr,an_spai,bn_spai] = ansbns(mup,phip,an(1),bn(1,:),pai0,pai1);

% construct state space matrices
[a,b,sigy,mu,phi,sigx] = statespacematrices(an,bn,an_sr,bn_sr,an_spai,bn_spai,sigy,mup,phip,pai0,pai1,sigma,sigpai);

% take out inflation part, if relevant
if nomreal == 0
    data = data(:,1:end-3);
    a    = a(1:end-3,1);
    b    = b(1:end-3,1:end-1);
    sigy = sigy(1:end-3,1:end-3);
    mu   = mu(1:nx,1);
    phi  = phi(1:nx,1:nx);
    sigx = sigx(1:nx,1:nx);
end

% calculate state estimates, covariances and loglik by kalman filter
[~,~,loglik] = kalmanfilter(a,b,sigy,mu,phi,sigx,data);

end