
function SE = getSE(params,calibrate,params_names,calibrate_names,lbounds,lbounds_names,ubounds,ubounds_names,data,mats,nx,nomreal,epsSE)
   
% Calculate Jacobian
numParams = size(params,2);
J = NaN(numParams,size(data,1)-6);
for i = 1:numParams
    paramsEpsp = params;
    paramsEpsp(i) = params(i) + epsSE;
    
    paramsEpsm = params;
    paramsEpsm(i) = params(i) - epsSE;
    
    loglikEpsp = model_output(paramsEpsp,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                                       ubounds,ubounds_names,data,mats,nx);
                                   
    loglikEpsm = model_output(paramsEpsm,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                                       ubounds,ubounds_names,data,mats,nx); 
                                   
    J(i,:) = (loglikEpsp.loglikpp' - loglikEpsm.loglikpp')/(2*epsSE);
end

% Fisher information matrix
I = zeros(numParams,numParams);
for t = 1:size(J,2)
    I = I + J(:,t)*J(:,t)';
end
I = I/size(J,2);

% Variance-covariance matrix
SE = inv(I)/size(data,1);

end