
function model = model_output(params,calibrate,params_names,calibrate_names,lbounds,lbounds_names,...
                    ubounds,ubounds_names,data,mats,nx,usp,pc)

% check bounds
if checkallbounds(lbounds,lbounds_names,ubounds,ubounds_names,params,params_names)
    model.loglik = 10^100;
    return;
end

% get model matrices
[muq,phiq,mup,phip,sigma,d0,d1,sigy,pai0,pai1,sigpai] = modelmatrices(params,params_names,calibrate,calibrate_names,nx,mats,usp);

% get yield factor loadings
[an,bn] = anbn(muq,phiq,sigma,d0,d1,mats);

% rotate to have pc's as factors
if pc > 0
    A    = an;
    B    = bn(:,nx-pc+1:end);
    C    = bn(:,1:nx-pc);
    RHO  = mup(1:nx-pc);
    MU   = mup(nx-pc+1:end);
    PSI  = phip(1:nx-pc,1:nx-pc);
    GAM  = phip(1:nx-pc,nx-pc+1:end);
    OME  = phip(nx-pc+1:end,1:nx-pc);
    PHI  = phip(nx-pc+1:end,nx-pc+1:end);
    SIGZ = sigma(1:nx-pc,:);
    SIGX = sigma(nx-pc+1:end,:);
    
    K = size(data(:,1:end-6),2);
    %V = cov(data(:,1:K)); SD = sqrt(diag(V)); R = V./(SD*SD'); [W,~,~] = pcacov(R); W = W'; PC = data(:,1:K)*W'; W = W(1:pc,:); PC = PC(:,1:pc);
    W = pca(data(:,1:K)); W = W(:,1:pc)'; PC = data(:,1:K)*W';

    
    WBi = inv(W*B);
    
    At    = (eye(K) - B*WBi*W)*A; an = At; 
    Bt    = B*WBi; bn(:,nx-pc+1:end) = Bt;
    Ct    = (eye(K) - B*WBi*W)*C; bn(:,1:nx-pc) = Ct;
    RHOt  = RHO - GAM*WBi*W*A; mup(1:nx-pc) = RHOt;
    MUt   = W*B*MU + W*A - W*B*PHI*WBi*W*A + W*C*RHO - W*C*GAM*WBi*W*A; mup(nx-pc+1:end) = MUt;
    PSIt  = PSI - GAM*WBi*W*C; phip(1:nx-pc,1:nx-pc) = PSIt;
    GAMt  = GAM*WBi; phip(1:nx-pc,nx-pc+1:end) = GAMt;
    OMEt  = W*C*(PSI-GAM*WBi*W*C) + W*B*(OME-PHI*WBi*W*C); phip(nx-pc+1:end,1:nx-pc) = OMEt;
    PHIt  = W*C*GAM*WBi + W*B*PHI*WBi; phip(nx-pc+1:end,nx-pc+1:end) = PHIt;
    SIGZt = SIGZ; sigma(1:nx-pc,:) = SIGZt;
    SIGXt = W*C*SIGZ + W*B*SIGX; sigma(nx-pc+1:end,:) = SIGXt;
end

% get short rate and inflation survey loadings
[an_sr,bn_sr,an_spai,bn_spai] = ansbns(mup,phip,an(1),bn(1,:),pai0,pai1);

% construct state space matrices
[a,b,sigy,mu,phi,sigx] = statespacematrices(an,bn,an_sr,bn_sr,an_spai,bn_spai,sigy,mup,phip,pai0,pai1,sigma,sigpai);

% add pc's as observables
if pc > 0
    data = [PC data];
    
    a = [zeros(pc,1);a];
    b = [zeros(pc,nx-pc) eye(pc) zeros(pc,1); b];
    sigy = [zeros(pc,pc) zeros(pc,size(sigy,2));...
            zeros(size(sigy,1),pc) sigy];
end 

% calculate state estimates, covariances and loglik by kalman filter
[states,covar,loglik,loglikpp] = kalmanfilter(a,b,sigy,mu,phi,sigx,data);

% calculate fitted data
data_fit = 1200*(repmat(a,1,size(states,1)) + b*states')';

% calculate residuals
resid = 1200*data-data_fit;

% calculate state innovations
invSigx = sigx(1:nx,1:nx)\eye(nx);
eps     = NaN(size(states,1),nx);
for t = 2:size(states,1)
    eps(t,:) = (invSigx*(states(t,1:nx)' - mu(1:nx,1) - phi(1:nx,1:nx)*states(t-1,1:nx)'))';
end

% calculate term premiums
rp = NaN(size(data,1),max(mats));
for n = 1:max(mats)
    if n == 1
        d0p = d0;
        d1p = [d1 0];
    else
        d0p = d0p + d1*phip^(n-1)*mup;
        d1p = [d1*phip^(n-1) 0];
    end
    rp(:,n)  = 1200*(d0p + d1p*states');
end
avgexp_r = cumsum(rp,2)./repmat(1:max(mats),size(data,1),1); 
tp       = data_fit(:,1:size(mats,2)) - avgexp_r(:,mats);

% report
model.a        = a;
model.b        = b;
model.sigy     = sigy;
model.mu       = mu;
model.phi      = phi;
model.sigx     = sigx;
model.states   = states;
model.covar    = covar;
model.loglik   = loglik;
model.yfit     = data_fit;
model.resid    = resid;
model.eps      = eps;
model.exp_r    = rp;
model.tp       = tp;
model.loglikpp = loglikpp;

end