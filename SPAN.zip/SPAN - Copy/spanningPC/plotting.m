
%% plot a few things

close all; clear; clc; addpath(genpath(pwd));

[y,m] = meshgrid((1983:2007)',(1:12));
dates = eomdate(y(:),m(:));
dates = dates(1:300);

figure(1)
hold on;
load('res_4fac_RW1_USP0_real0_pc0.mat');
plot(dates,1200*data(:,11),'ob');
plot(dates,model.yfit(:,11),'-k');
load('res_4fac_RW1_USP0_real0_pc1.mat');
plot(dates,model.yfit(:,14),':k');
load('res_4fac_RW1_USP1_real0_pc0.mat');
plot(dates,model.yfit(:,11),'-r');
load('res_4fac_RW1_USP1_real0_pc1.mat');
plot(dates,model.yfit(:,14),':r');
axis('tight')
ylim([0 15]);
dateaxis('x');
legend('Surveys','4fac,RW1,USP0,pc0','4fac,RW1,USP0,pc1','4fac,RW1,USP1,pc0','4fac,RW1,USP1,pc1');
legend('boxoff');
title('i* estimates');

